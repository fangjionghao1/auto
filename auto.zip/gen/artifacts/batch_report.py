from paper_helpers import project
from pathlib import Path
import json,subprocess,sys
base=Path('D:/wkplace/auto/gen')
# Full recursive enumeration also includes hidden directories, independent of rg ignore settings.
pairs=sorted({f.parent for f in base.rglob('src.md') if (f.parent/'speek.md').is_file()})
assert len(pairs)==3
subprocess.run([sys.executable,str(project(2)/'仿真/R1/verify_results.py')],check=True,stdout=subprocess.DEVNULL)
lines=['# 批量论文执行报告','日期：2026-10-08。已递归复查整个D:/wkplace/auto/gen，符合src.md与speek.md同目录条件的项目共3个，均完成生成与技术核验。生成出的数据、图和排版子目录不作为新论文任务。','', '本次技术交付3项；正式已完成0项；待签署3项；待重设计0项；符合条件但未生成0项；台账中另有待定位2项。','', '每项均交付中英MD、原生公式Word和PDF，实际MATLAB实验、原始逐点数据、可编辑FIG、独立数值复算、文献元数据、模拟审稿及哈希证据。中英各5页，失败试验与较差比较结果如实保留。','']
for i in range(3):
 p=project(i);st=json.loads((p/'.paper-pipeline/status.json').read_text(encoding='utf-8'))
 lines += ['## '+st['title'],'状态：待签署。',f'- [中文Word]({(p/"论文_zh.docx").as_posix()})',f'- [英文Word]({(p/"论文_en.docx").as_posix()})',f'- [仿真包]({(p/"仿真/仿真打包.zip").as_posix()})',f'- [技术审稿报告]({(p/"审稿报告.md").as_posix()})','']
lines += ['## 正式签署与剩余台账','goal.md对应三项已更新为待签署，并自动保存修改前备份。项目审稿规程要求FJH签署，尚未取得；依据paper-batch-pipeline规则“要求正式签署而尚未签署时填‘待签署’，不得代签”，未标记已完成。','', '以下两项台账进度仍为进行中，但在gen下没有包含src.md和speek.md的匹配目录，不符合本次先行条件，未创建虚假完成记录：','- 基于时空图神经网络大模型的区域配电网负荷预测仿真','- 基于多尺度一维卷积神经网络的变压器扫频阻抗曲线故障诊断系统','', '台账已有“状态已完成、进度进行中”的不一致原值保持不变。当前不能宣称整个台账没有未完成任务；本次所有符合条件的论文生成工作已处理完毕。','', '[台账](D:/wkplace/auto/src/goal.md) · [最终扫描](D:/wkplace/auto/.paper-pipeline/scan-20261008-final.json) · [审稿规程](D:/wkplace/auto/test/script/README.md)']
(base/'批量执行报告_20261008.md').write_text('\n'.join(lines),encoding='utf-8')
print('Full scan: 3 eligible projects; report saved; packaged verifier passed.')
