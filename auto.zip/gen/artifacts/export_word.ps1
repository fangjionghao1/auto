param([Parameter(Mandatory=$true)][string]$DocPath,[Parameter(Mandatory=$true)][string]$PdfPath)
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
  $document = $word.Documents.Open($DocPath, $false, $true)
  $document.Repaginate()
  $document.ExportAsFixedFormat($PdfPath,17)
  $document.Close(0)
} finally { $word.Quit() }
