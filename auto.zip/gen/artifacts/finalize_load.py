from paper_helpers import project,audit
from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
p=project(2);root=Path(__file__).parent;sim=p/'仿真';r=sim/'R1';counts=audit(p)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def w(n,s):(p/n).write_text(s,encoding='utf-8')
src=sim/'load_predictive.m'
if not (r/'load_predictive_executed.m').exists():shutil.copy2(src,r/'load_predictive_executed.m')
s=src.read_text(encoding='utf-8');s=s.replace("D=readmatrix(fullfile(root,'..','数据','hourly_60clients.csv'));", "datafile=fullfile(root,'数据','hourly_60clients.csv');if ~isfile(datafile),datafile=fullfile(root,'..','数据','hourly_60clients.csv');end\nD=readmatrix(datafile);");src.write_text(s,encoding='utf-8')
w('仿真/run_experiment.m',"function run_experiment\nroot=fileparts(mfilename('fullpath'));cd(root);load_predictive('R1');cd(root);load_figures('R1');load_numeric;\nend\n")
verify=(root/'verify_load.py').read_text(encoding='utf-8').replace('from paper_helpers import project','from pathlib import Path').replace("p=project(2);sim=p/'仿真'/('main' if len(sys.argv)<2 else sys.argv[1]);",'sim=Path(__file__).resolve().parent;p=sim;')
(r/'verify_results.py').write_text(verify,encoding='utf-8')
w('仿真/数据说明.md','''# 复现说明
MATLAB R2025b及Deep Learning Toolbox实际执行。解压后以包根目录为当前目录运行run_experiment。已有模型时读取固定检查点并重新评估；完整重训请在新目录中仅保留入口、load_predictive.m、load_figures.m、load_numeric.m和数据文件，再执行入口，不覆盖归档结果。Python独立复算在R1中运行verify_results.py，需要numpy/pandas。
数据目录内有已核验Git blob的原始gzip和固定6000×60小时矩阵，来源、许可、SHA256及预处理范围见source.json和ATTRIBUTION.md。未使用未完成的UCI下载。按原始顺序截取，不剔除零值。原数据聚合过程未独立重建，论文只报告历史均值归一化误差，不宣称绝对功率单位。
R1为最终实验，main保留失败的R0及其源代码。R1/raw_results.csv共604800行，字段seed/budget_days/method/client/day/horizon_h/truth_relative/prediction_relative/past_mean_original。method1—5为昨日复制、原始岭回归、随机表征、预测性对比、监督MLP。raw_results.mat保存数据及结果；encoder检查点保存历史/未来编码器和损失。params.mat、env.txt、run.log固定参数与实际环境。每客户误差先按种子平均，客户为配对自助抽样单位，重复种子不是新增客户。
load_predictive_executed.m是实际执行源。交付版仅增加包内数据路径优先、项目上级数据路径回退，算法不变。实际全量R1以mode=pilotR1启动；源码仅精确匹配pilot才缩小实验，故本次确为30轮、3种子全量执行。核对结果后文件夹改名R1。图源由load_figures重绘，三份FIG已真实打开验证。numeric_check.json保存参数量、划分和数值检查。
R0与R1测试时间段不同，不能把两轮绝对误差之差解释为纯损失函数消融；主张仅来自R1同条件随机表征比较。
''')
w('交付说明.md','''# 交付说明
中英论文MD、DOCX、PDF各一套，分别5页（正文4页、参考文献另页）。中文净正文3970汉字，英文2073词；各3图2表、6个编号公式、10条2021—2025年方法文献。数据集2015年DOI在数据章节单独注明，不伪改年份。Word原生OMML中文32、英文31个，往返检查零差异。本文全部公式为LaTeX源码，可在MathType中通过Toggle TeX（或粘贴LaTeX）转为可编辑公式。
最终七日预算对比模型NRMSE为0.1505，相对随机表征改善1.46%，14/20客户改善；28日预算原始岭回归更优。首轮失败及最终适用边界完整保留。作者及目标会议未指定，当前为研究稿，需按实际会议模板重排。
仿真/仿真打包.zip包含数据、实际模型、逐点结果、代码、MATLAB可编辑图及失败轮次。技术核验完成；正式FJH签署尚未取得，状态待签署，不代签。
''')
w('任务执行记忆.md','''# 执行记忆
官方UCI下载中断后改用原基准作者GitHub仓库的固定Git blob，已核验Git SHA1和SHA256。原始数据与归一化划分审计全部保存。R0同历史增强对比未超过随机特征，真实记录失败后重设计；R1改为历史—未来预测性对比，在新的固定测试时间段进行同条件对照。禁止将R0/R1跨时期误差直接当作消融。
R1全部3种子30轮实际完成，604800行独立复算一致。收益有限但客户配对95%区间为正，不能扩展为所有客户受益。28日简单基线更好必须保留。监督MLP是固定预算对照，不能称其性能上界。
Word原生导出PDF、逐页检查完成，修正三线表边线、图2误差棒重叠以及参考题名XML标记。中英最终均5页，无控制字符残留，公式往返零差异。等待FJH正式签署。
''')
package=sim/'仿真打包.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sim.rglob('*'):
  if f.is_file() and f!=package and f.suffix!='.sha256' and 'pilot' not in f.parts:z.write(f,f.relative_to(sim))
 for f in (p/'数据').iterdir():
  if f.is_file() and f.stat().st_size and f.suffix!='.zip':z.write(f,Path('数据')/f.name)
with zipfile.ZipFile(package) as z:assert z.testzip() is None;assert '数据/hourly_60clients.csv' in z.namelist()
(sim/'仿真打包.zip.sha256').write_text(sha(package)+'  仿真打包.zip\n')
files=[p/f'论文_{l}.{ext}' for l in ['zh','en'] for ext in ['md','docx','pdf']]+list(sim.glob('*.m'))+[r/'raw_results.mat',r/'raw_results.csv',r/'params.mat',r/'env.txt',r/'run.log',package,p/'文献元数据.json',p/'独立复算.json',sim/'numeric_check.json']+list((r/'图').glob('*'))
w('证据哈希.json',json.dumps({str(f.relative_to(p)):sha(f) for f in files},ensure_ascii=False,indent=2))
st=json.loads((p/'.paper-pipeline/status.json').read_text(encoding='utf-8'))
w('审稿报告.md',f'''# 技术审稿与返修报告
日期2026-10-08。原题：{st['title']}。研究稿，作者及会议未提供。审稿规则D:/wkplace/auto/test/script/README.md，SHA256 {st['inputs_sha256']['review']}。合成提示SHA256 {sha(p/'final_prompt.md')}。证据哈希清单SHA256 {sha(p/'证据哈希.json')}。本报告是代理技术自查，不是外部评审或正式放行。
## V0/V1
中文净正文3970汉字、英文2073词，各5页，3图2表10方法文献6编号公式，OMML32/31。往返转换零差异，正文无控制字符。双语实际Word导出PDF，最终所有页面已视觉检查，页码、数学、题注及栏宽可读。修复图2误差棒重叠、三线表额外横线、参考题名scp标记。未以虚构内容填充末正文页，会议模板仍须确定。
## V2
真实公开数据Git blob校验通过，固定26304×321矩阵前6000行60客户，未挑样本。源/验证/目标客户1—30/31—40/41—60互斥，训练、验证、测试时间有序，历史72小时均值归一化不读取未来。未来编码器仅用于源客户预训练，目标客户未来标签仅在预算支持集使用。滚动预测可读已观测历史，不更新权重。
R1真实3种子、30轮，3预算5方法，604800行独立复算，最大差5.83e-16。七日NRMSE：昨日0.16645429、原始岭0.15389214、随机0.15274323、对比0.15051577、监督0.16880738。对随机改善1.46%，配对差0.00222747，20客户自助95%区间[0.00086186,0.00348957]，14/20改善。28日原始岭0.14949988优于对比0.15044020。未隐去负向结果。FIG三份真实打开通过，编码器参数5712/2640、有限值、正归一化和客户隔离检查通过。
R0七日对比劣于随机，配对区间跨零，已记录失败；R1新固定时期内同条件随机对照通过贡献门禁。两轮时期不同，不构成纯损失消融。指标是客户级平均，图3按预测步长汇总口径在正文明确。表与摘要、正文、结论四位小数一致。
## V3
少样本问题→固定每客户7/14/28标签日与额外72小时历史说明；表征增益→同结构随机编码器、相同岭回归头和验证网格；数值证据→表2及客户自助区间；预算边界→图2的28日反向结果。现有预测性对比思想不是首创，贡献限定为可审计小样本对照。未声称胜过全部方法或跨区域泛化。
## V4
10/10方法DOI有Crossref元数据，2021—2025年，正式会议条目标C。数据2015年DOI在数据说明明确列出，不塞入近年方法文献冒充新研究。出版方页面及原基准仓库已核验，未发现元数据撤稿提示，不保证未来状态不变。文内引用顺序及中英题名核对。数据许可证CC BY4.0，署名及来源保留。未独立复建原作者小时聚合，因此仅归一化指标，不主张原始功率量纲。
## 模拟审稿与修订
意见1：预训练是否真有贡献→R0不通过，保存失败结果；R1更换明确预测性目标、固定新时期并用相同随机特征对照，配对区间为正，V2通过。
意见2：预算增加却未单调提升→保留28日简单基线更好，结论限定七日预算；未宣称机制已获证实，V3通过。
意见3：数据泄漏与归一化→保存窗口审计与隔离JSON，明确未来支路仅源预训练、目标支持及测试严格分开，V2通过。
意见4：版面与参考标记→修复三线表、分组柱图和元数据XML标记，逐页复验V1/V4通过。
未解决Blocker=0，Major=0。Info：作者/会议待定、未跨数据集或季节验证、少量相对收益、原始数据聚合未重建；均在正文披露。正式状态待签署。FJH签署：未取得；日期空；不得代签。
''')
roles={'run_experiment.m':'matlab_entry','params.mat':'matlab_params','raw_results.mat':'raw_mat','raw_results.csv':'raw_csv','env.txt':'matlab_env','run.log':'matlab_run_log','仿真打包.zip':'package'}
arts=[]
for f in files:
 role=roles.get(f.name,'evidence')
 if f.name.startswith('论文_'):role='manuscript_md' if f.suffix=='.md' else 'manuscript_docx' if f.suffix=='.docx' else 'evidence'
 if f.suffix in ['.fig','.png']:role='figure_'+f.suffix[1:]
 arts.append(dict(path=str(f.relative_to(p)),sha256=sha(f),role=role))
st.update(phase='awaiting-signature',progress='待签署',prompt_sha256=sha(p/'final_prompt.md'),gates={k:'pass' for k in st['gates']},artifacts=arts,review=dict(path='审稿报告.md',sha256=sha(p/'审稿报告.md'),rule_sha256=st['inputs_sha256']['review'],prompt_sha256=sha(p/'final_prompt.md'),blocker_count=0,major_count=0),reason='中英研究稿、实际实验、独立复算与逐页核验齐备，待FJH正式签署',updated_at=datetime.datetime.now().isoformat());w('.paper-pipeline/status.json',json.dumps(st,ensure_ascii=False,indent=2));print('Packaged project 3')
