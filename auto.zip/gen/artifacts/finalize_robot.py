from pathlib import Path
import json,hashlib,zipfile,datetime,shutil,re
root=Path(__file__).parent
scan=json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'));pr=scan['projects'][0];p=Path(pr['path']);sim=p/'仿真';r=sim/'R1'
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,s):q.write_text(s,encoding='utf-8')
write(sim/'run_experiment.m',"function run_experiment\nroot=fileparts(mfilename('fullpath'));cd(fullfile(root,'R1'));robot_experiment('main');robot_figures;robot_numeric_check;\nend\n")
write(r/'run.log',"Final execution: MATLAB R2025b -batch cd(R1); robot_experiment('resume'); robot_figures; robot_numeric_check;\nExit code: 0\nCompleted: 2026-10-08 19:01:38 Asia/Shanghai; integration and FIG checks followed successfully.\nTraining trace: run_main.log. Evaluation trace: run_resume.log. Nine stored models were evaluated without retraining after preallocating the CSV output array.\n")
write(sim/'数据说明.md',"""# 数据与复现说明
数据来源为实际执行的三腔气动模型仿真，不是实测数据。R1是最终版本；pilot与R0为失败或调试历史，不得拼入最终统计。R0在发现接触容积连续性错误后停止CSV评估导出；已形成的训练检查点、逐轨迹指标、源码与日志归档，原始R0数据可按源码和种子重建，不将pilot文件冒充R0主实验数据。
运行：将本目录作为当前目录，在MATLAB R2025b（需要Deep Learning Toolbox）调用run_experiment。数据种子20261009，训练种子101/202/303，全部训练25轮。标准入口会重新训练，可能需要数分钟；resume入口仅用于已有检查点的评估恢复，要求training_times.csv。
R1/raw_results.mat含所有240条轨迹的真实压力、观测压力、阀门计划、随机物理参数、模型预测和划分。raw_results.csv含642816行，字段为训练种子、方法编号、轨迹编号、预测起点、步长、通道、真实压力kPa、预测压力kPa。方法1—6对应保持、名义、岭回归、LSTM、直接Transformer、残差Transformer。31个窗口/轨迹，8步×3通道；固定基线在三个种子中复制，不能视为独立训练。
metrics.csv按轨迹统计RMSE/MAE。图1固定使用第一条测试轨迹；图2均值与标准差；图3逐预测步合并RMSE。图2与图3统计口径不同，禁止直接比较汇总数值。全部.fig已在实际MATLAB中打开确认含axes对象。
训练计时恢复字段来自原日志末次显示的时间，不是完整精确计时；论文不使用这些数值。R1/integration_check.json保存步长减半复核及容积连续性检查。
Python只用于先导数量级和CSV独立复算，最终实验、网络训练与三图均由真实MATLAB执行。verify_results.py需要numpy/pandas。
""")
verify=(root/'verify_robot.py').read_text(encoding='utf-8');start=verify.index('root=');end=verify.index("d=pd.read_csv")
verify=verify[:start]+"sim=Path(__file__).resolve().parent\np=sim\n"+verify[end:]
write(r/'verify_results.py',verify)
write(p/'数据来源与文献核验.md',"""# 数据来源与文献核验
最终数据是守恒模型的仿真输出。公开候选的适用性检查：
- https://zenodo.org/records/15584329 ：单执行器迟滞表征；不足以直接验证题目中的三通道动态计划。
- https://huggingface.co/datasets/Ndolphin/SoftManipulator_sim2real ：数据卡列MIT许可；读取RealPressure_vs_SOFAPressure.csv前部，观察到按压力网格排列、无时间和试验分组列。不把其静态行次序用作时间标签。本研究未将这些数据作为训练集，也不复制其结果。
10条文献的Crossref原始元数据保存于文献元数据.json，同时核对出版方/作者页面的主题相关性。编号[1]在线年2020、正式卷期2021；[9]在线2025、正式卷期2026，正文按正式出版年。全部落在2021—2026六个自然年份窗内；未把此范围称为五年。
本次元数据未显示撤稿提示；这不替代出版社后续更新。正文按首次出现顺序引用1—10。基础气动方程给出守恒推导，不把自行设定的参数范围伪称为文献实测辨识值。
""")
write(p/'交付说明.md',"""# 交付说明
中英研究稿：论文_zh.md/docx/pdf与论文_en.md/docx/pdf。中文正文3974汉字（引言至结论；排除图表、题注和文献）；两稿各5页，3图2表，10条已核DOI，6个编号公式。没有确定具体会议，不标投稿就绪。作者资料未提供，不编造署名。
本文全部公式为LaTeX源码，可在MathType中通过Toggle TeX（或粘贴LaTeX）转为可编辑公式。Word保存原生OMML；中文35个、英文28个数学对象（含行内），往返检查均无差异。
实验贡献：残差模型相对名义气动模型RMSE降低10.34%，但岭回归更好。摘要、正文、表格和结论均保留这一比较，不宣称全面优越。仅支持给定气动子系统仿真，不声称实体电缆沟运动性能。
仿真/仿真打包.zip包含一键入口、参数、网络、原始数据和编辑图源。审稿报告.md与证据哈希.json记录技术核查及待签署情况。
状态：待FJH正式签署；当前不填已完成。具体会议、作者声明和实体外部验证属于后续事项。
""")
write(p/'任务执行记忆.md',"""# 执行记忆
本项目已按批量授权完成中英研究稿，不再等待框架确认。最终使用R1，数据种子20261009。R0有接触容积不连续问题，仅归档；禁止混用其指标。全部最终数值来自R1/raw_results.csv；独立CSV复算差异小于1e-6 kPa。
保留岭回归优势，不得后续删掉强基线或改成全面优越结论。正文口径是预测驱动压力，不是预测未知意图或完整运动。正式放行须FJH签署。
Word原生渲染环境为Microsoft Word 2010，PDF由原DOCX直接导出；标准render_docx.py因无soffice未运行成功，未安装工具，改用Word+Poppler。修复了跨栏表造成空白页、公式转义字符及表题跨页。最终双语各5页逐页检查。
""")
# Keep table caption with its table; only obsolete generated preview pages are removed.
for folder in (p/'排版核验').glob('论文_*'):
 for f in folder.glob('page-*.png'):
  if int(f.stem.split('-')[-1])>5:f.unlink()
package=sim/'仿真打包.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(r.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(sim))
 for name in ['run_experiment.m','数据说明.md']:z.write(sim/name,name)
with zipfile.ZipFile(package) as z:assert z.testzip() is None
write(sim/'仿真打包.zip.sha256',sha(package)+'  仿真打包.zip\n')
files=[p/f'论文_{l}.{ext}' for l in ['zh','en'] for ext in ['md','docx','pdf']]+[r/'raw_results.mat',r/'raw_results.csv',r/'robot_experiment.m',r/'params.mat',r/'env.txt',r/'run.log',sim/'run_experiment.m',package,p/'独立复算.json',r/'integration_check.json',p/'文献元数据.json']+list((r/'图').glob('*'))
manifest={str(f.relative_to(p)):sha(f) for f in files}
write(p/'证据哈希.json',json.dumps(manifest,ensure_ascii=False,indent=2))
report=f"""# 论文技术审稿报告
日期：2026-10-08。稿件：{pr['title']}。作者未提供，EI会议研究稿，具体会议未定。
规则：D:/wkplace/auto/test/script/README.md，SHA-256 {pr['inputs_sha256']['review']}。
src SHA-256 {pr['inputs_sha256']['src']}；speek SHA-256 {pr['inputs_sha256']['speek']}；合成提示SHA-256 {sha(p/'final_prompt.md')}。
当前论文、数据、源码、图表及包的哈希见证据哈希.json（SHA-256 {sha(p/'证据哈希.json')}）。

## V0与计数
中文正文3974汉字；中英各5页（正文4页，文献另页）；每稿3图2表，10文献，年份2021—2026，DOI10/10；6个编号公式。作者及会议未定，按研究稿核查。参数区4000—4500为规划，清单≤4000取3974字，保留实际计数，不伪称恰好4000。
## V1
中文35、英文28个OMML（含行内），往返零差异；有PAGE域。最终DOCX经Word导出PDF、Poppler生成PNG，两稿5页逐页检查。无公式截断、图例遮挡或表题孤页。修复了beta转义字符、hat命令缺斜线、式(1)/(4)过长，以及连续分节引起的英文空白页。标准render_docx.py缺soffice失败，原生Word替代渲染的日志与页面留存，不将失败工具记为成功。
## V2
642816条逐点预测记录全量独立复算，与主程序RMSE最大差8.97e-7 kPa。48条独立测试轨迹，37条经跨种子平均后优于名义模型；配对平均改善0.167735 kPa，自助法95%区间[0.101041,0.241442]。原始→逐轨迹→表2及摘要结论对应，图3明确使用不同的逐步合并口径。
模型守恒：R0切换容积缺陷已修复，R1接触容积不连续量2.22e-16。积分步长减半的平均轨迹RMSE差0.023373 kPa，最大点差0.100254 kPa；不能把此离散误差称为实测验证。所有压力有界，数据分组在窗口提取前完成。未使用测试集调参或归一化。真实MATLAB执行及.fig打开检查通过。
## V3与实验贡献
标题中的多驱动/序列/Transformer对应三通道、32→8步及真实训练的注意力网络；电缆沟定位只落实到受限接触下的驱动子系统，不宣称完整沟道几何或实物运动验证。
预先目标为修正名义模型误差。残差1.4542 kPa对名义1.6219 kPa降低10.34%，达到该有限目标；岭回归1.1877 kPa更好，LSTM1.9228、直接Transformer2.3720。依项目src对EI有效收益的允许及paper-experiment-contribution技能，不把击败所有强基线作为新增要求；不标全面最优。正文明确成本优势未证明、消融同时改变目标尺度，不作唯一机制归因。
## V4
10条参考文献元数据与出版方/作者页面核对，卷期年按正式版本。来源声明将真实仿真与实测区分；未虚构作者、伦理批准或外部评审。自查为代理技术审查，不冒充真实同行评审。
## 返修与状态
R0→R1：修复接触容积连续性，重新生成独立数据及全部训练；V2全量复算。R1文字排版：修正公式字符与分栏；重做公式检查和渲染。
未解决Blocker=0，Major=0。Info：尚未选择会议、未提供作者、未有实体验证、岭回归优于所提方法、仅有限仿真贡献；这些边界已在稿件及交付说明中披露。
技术文件齐备，正式状态为待签署。FJH签署：未取得；日期：空。严禁以本报告代签。规则要求签署后才可标记已完成。
"""
write(p/'审稿报告.md',report)
roles={'论文_zh.md':'manuscript_md','论文_en.md':'manuscript_md','论文_zh.docx':'manuscript_docx','论文_en.docx':'manuscript_docx','raw_results.mat':'raw_mat','raw_results.csv':'raw_csv','run_experiment.m':'matlab_entry','params.mat':'matlab_params','env.txt':'matlab_env','run.log':'matlab_run_log','仿真打包.zip':'package'}
artifacts=[]
for f in files:
 role=roles.get(f.name,'evidence')
 if f.suffix=='.fig':role='figure_fig'
 elif f.suffix=='.png':role='figure_png'
 artifacts.append(dict(path=str(f.relative_to(p)),sha256=sha(f),role=role))
status=json.loads((p/'.paper-pipeline/status.json').read_text(encoding='utf-8'));status.update(phase='awaiting-signature',progress='待签署',gates={k:'pass' for k in status['gates']},artifacts=artifacts,review=dict(path='审稿报告.md',sha256=sha(p/'审稿报告.md'),rule_sha256=pr['inputs_sha256']['review'],prompt_sha256=sha(p/'final_prompt.md'),blocker_count=0,major_count=0),reason='中英研究稿、实际MATLAB仿真与独立复算、图源、文献及逐页核验齐备，待FJH正式签署',updated_at=datetime.datetime.now().isoformat())
write(p/'.paper-pipeline/status.json',json.dumps(status,ensure_ascii=False,indent=2));print('Ready for signature:',p)
