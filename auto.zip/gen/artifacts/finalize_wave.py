from paper_helpers import project,audit
from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
p=project(1);root=Path(__file__).parent;sim=p/'仿真';r=sim/'main';counts=audit(p)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def w(n,s):(p/n).write_text(s,encoding='utf-8')
verify=(root/'verify_wave.py').read_text(encoding='utf-8');a=verify.index('p=Path(');b=verify.index('d=pd.read_csv')
verify=verify[:a]+"sim=Path(__file__).resolve().parent\np=sim\n"+verify[b:];(r/'verify_results.py').write_text(verify,encoding='utf-8')
w('仿真/数据说明.md','''# 复现说明
真实MATLAB R2025b及Deep Learning Toolbox执行。以仿真目录为当前目录调用run_experiment，main为主实验，pilot为独立先导。已有模型时入口重新生成固定数据并评估保存模型；完整重训请使用空白复现目录，仅复制m文件后运行，不覆盖归档结果。
raw_data.mat保存全部2550个事件的干净波形、观测、正则逆、精确逆、测量常数、SNR、到达时刻及划分。raw_results.mat保存450个测试事件、五方法、三个种子的预测。raw_results.csv有1296000行，字段event/seed/method/time_us/truth_kV/prediction_kV/snr_dB。方法1—5依次为观测、精确逆、正则逆、直接CNN、残差CNN。
wave_experiment.m训练并导出；wave_final_figures.m生成最终栏宽适配图；wave_numeric.m核验无噪逆和FIG结构。run.log是实际执行日志。params.mat及源码共同固定所有参数，模型检查点保存真实训练网络和耗时。图2误差棒是先对种子平均后跨事件标准差，不是置信区间；图3为对数纵轴。
Python独立复算脚本verify_results.py需要numpy/pandas，独立实现半峰插值，不读取主程序指标代替计算。参数范围为仿真假设，不是测得电缆参数。
''')
w('交付说明.md','''# 交付说明
中英研究稿论文_zh/en.md、docx、pdf，双语各5页（正文4页、参考文献另页）；中文正文3942汉字，英文正文约2089词，按报告口径排除表格、题注、参考文献。每稿3图2表、10条2021—2026年带DOI参考文献、5个编号公式。会议与作者未指定，不称投稿就绪。
本文全部公式为LaTeX源码，可在MathType中通过Toggle TeX（或粘贴LaTeX）转为可编辑公式。Word保存原生OMML，中文32、英文30个数学对象（含行内）；往返检查零差异，页码齐备。
残差模型对正则逆RMSE改善74.81%，但直接CNN更好，摘要及结论均完整保留该结果。实验是已知一阶测量链下的参数化仿真，未开展实物测量与完整测距。
仿真/仿真打包.zip含源码、原始数据、网络和可编辑图源。技术核验已完成，依规则仍待FJH正式签署，不代签、不标已完成。
''')
w('任务执行记忆.md','''# 执行记忆
最终为main，数据种子20261010，1800/300/450事件，三训练种子101/202/303。pilot仅2轮，直接CNN未收敛；主实验20轮后直接CNN优于残差，禁止使用先导排序代替主实验。CNN波头反演已有2026年工作，本稿限定为时域条件反演比较，不声称首创。
真实脚本首先修复grid变量与grid命令重名，以及MATLAB路径中main名称导致的目录存在判断；这些是执行前实现错误，没有伪造失败实验结果。主实验一次完整执行成功，未挑种子、样本或测试参数。
Word通过原生Word导出PDF及Poppler逐页检查；修复单位命令、图例过小、表格多余边线及英文正文被误判为图题。标准soffice路径不可用，未把失败渲染器当成成功。最终数值保持不变。待FJH正式签署。
''')
package=sim/'仿真打包.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sim.rglob('*'):
  if f.is_file() and f!=package and f.suffix!='.sha256' and 'pilot' not in f.parts:z.write(f,f.relative_to(sim))
with zipfile.ZipFile(package) as z:assert z.testzip() is None
(sim/'仿真打包.zip.sha256').write_text(sha(package)+'  仿真打包.zip\n')
files=[p/f'论文_{l}.{ext}' for l in ['zh','en'] for ext in ['md','docx','pdf']]+list(sim.glob('*.m'))+[r/'raw_data.mat',r/'raw_results.mat',r/'raw_results.csv',r/'params.mat',r/'env.txt',r/'run.log',package,p/'文献元数据.json',p/'独立复算.json',sim/'numeric_check.json']+list((r/'图').glob('*'))
w('证据哈希.json',json.dumps({str(f.relative_to(p)):sha(f) for f in files},ensure_ascii=False,indent=2))
st=json.loads((p/'.paper-pipeline/status.json').read_text(encoding='utf-8'))
w('审稿报告.md',f'''# 技术审稿与返修报告
日期2026-10-08。项目原题：{st['title']}。研究稿，目标会议及作者未提供。规则D:/wkplace/auto/test/script/README.md，SHA256 {st['inputs_sha256']['review']}。合成提示SHA256 {sha(p/'final_prompt.md')}。产物哈希见证据哈希.json（{sha(p/'证据哈希.json')}）。本自查不是正式放行签署。
## V0/V1
中文净正文3942汉字；英文净正文2089词（结构核验工具口径），各5页。3图2表，10条文献，5编号公式，OMML32/30，往返无差异。无控制字符残留。标题、图例、表头、页码及公式已逐页检查。图和表格缩入栏宽后文字可读；末正文页未用空白填充或虚构内容凑满。修复了英文Figure 3开头正文被转换器误判题注、表头单位拆字、三线表多余横线、公式rm单位残留。最终Word原生导出PDF检查，源文件一致。
## V2
真实主实验六个模型、三种子、450独立测试事件，1296000逐点预测行。Python全量重算RMSE、MAE及半峰插值，和主程序最大差3.89e-16。残差RMSE0.010455154565、正则逆0.041499754183，改善74.81%；配对平均差0.0310446 kV，自助95%区间[0.0301147,0.0319977]，450事件均改善。直接CNN0.009595047021更低，未隐去。
摘要/4.2/表2/结论统一4位小数；图2为事件RMSE均值和标准差；图3按150事件每SNR档位汇总。训练种子复制解析基线不算独立样本。噪声定义、样本划分、已知时间常数公平性、验证选择lambda=0.1和训练目标尺度已核。无噪离散逆最大误差4.44e-16 kV，极点稳定；FIG已真实打开确认axes。模型为参数化到达波形与一阶测量链，不能外推完整线路或实体测距。
## V3
波头反演→式(1)—(4)及图1；恢复收益→表2/图2；定时抗噪→固定半峰定义/图3；残差结构必要性→直接CNN对照。主实验直接形式更好，已在摘要及结论保留，未为维护原假设删改比较。当前贡献是明确条件下的恢复实验，不声称提出首个CNN反演或新结构。
## V4
10/10 DOI有Crossref元数据，正式出版年均在2021—2026，Lan按2023、综述按2021；第5条通过J-STAGE，近邻工作通过出版方全文，第10条编码损坏题名以Wiley校正。未发现元数据撤稿提示；不代替出版方持续更新。文内1—10首次顺序一致。没有虚构署名、伦理审批或真实审稿意见。
## 模拟审稿及修订
意见1：先导与主实验排序不同，不应宣称残差必优→保留直接模型最优结果，摘要及4.2/结论一致，V2/V3复验。
意见2：已有CNN波头反演文献，创新表述过宽→引言明确引用[6]，限定时域条件比较，V4复验。
意见3：缩栏图例与单位可读性→脚本重新输出500像素逻辑宽度图、修正单位及表头，双语5页复验。
以上为代理模拟审查，不是外部同行评审。未解决Blocker=0，Major=0。Info：研究稿、未选会议、未提供作者、尚无实体与测量失配验证；最终版面需按所选会议模板重排。
正式状态待签署。FJH签署：未取得；日期空。不得由本代理代签。
''')
roles={'run_experiment.m':'matlab_entry','params.mat':'matlab_params','raw_results.mat':'raw_mat','raw_results.csv':'raw_csv','env.txt':'matlab_env','run.log':'matlab_run_log','仿真打包.zip':'package'}
arts=[]
for f in files:
 role=roles.get(f.name,'evidence')
 if f.name.startswith('论文_'):role='manuscript_md' if f.suffix=='.md' else 'manuscript_docx' if f.suffix=='.docx' else 'evidence'
 if f.suffix in ['.fig','.png']:role='figure_'+f.suffix[1:]
 arts.append(dict(path=str(f.relative_to(p)),sha256=sha(f),role=role))
st.update(phase='awaiting-signature',progress='待签署',prompt_sha256=sha(p/'final_prompt.md'),gates={k:'pass' for k in st['gates']},artifacts=arts,review=dict(path='审稿报告.md',sha256=sha(p/'审稿报告.md'),rule_sha256=st['inputs_sha256']['review'],prompt_sha256=sha(p/'final_prompt.md'),blocker_count=0,major_count=0),reason='中英研究稿、实际仿真、独立复算与逐页核验齐备，待FJH正式签署',updated_at=datetime.datetime.now().isoformat());w('.paper-pipeline/status.json',json.dumps(st,ensure_ascii=False,indent=2));print('Packaged',p)
