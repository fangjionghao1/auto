from pathlib import Path
import json,re
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
q=p/'论文_zh.md';s=q.read_text(encoding='utf-8')
s=s.replace(chr(9)+'au_i',r'\tau_i').replace('$ell_i$',r'$\ell_i$')
s=s.replace('这里$\\tau_i$为名义时间常数',r'接触前$a_i=1$；切换时设$a_i=1+(c_{i,old}-c_{i,new})p_i^*/P_0$，使归一化容积$a_i+c_i p_i/P_0$连续，保持切换瞬间的压力与气体质量连续。这里$\tau_i$为名义时间常数')
s=s.replace('压力和指令以60 kPa归一化','压力和指令以60 kPa归一化')
q.write_text(s,encoding='utf-8')
for x in re.findall(r'(?<!\$)\$(?!\$)([^$\n]+)\$(?!\$)',s):print(repr(x))
