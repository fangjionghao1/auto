from paper_helpers import project
import pandas as pd,numpy as np,json,hashlib
p=project(2);f=p/'数据/hourly_60clients.csv';D=pd.read_csv(f).to_numpy();src=set(range(1,31));val=set(range(31,41));tar=set(range(41,61));assert not(src&val or src&tar or val&tar)
windows=[]
for role,clients,days in [('source',src,range(4,149)),('validation',val,range(177,191)),('test',tar,range(219,247))]:
 for c in sorted(clients):
  for day in days:
   start=(day-1)*24;mu=D[start-72:start,c-1].mean();assert mu>0 and np.isfinite(mu)
   windows.append({'role':role,'client':c,'day':day,'history_start_row_1based':start-71,'history_end_row_1based':start,'future_start_row_1based':start+1,'future_end_row_1based':start+24,'past_mean':mu})
pd.DataFrame(windows).to_csv(p/'数据/窗口审计_R1.csv',index=False)
out={'input_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'no_missing':bool(np.isfinite(D).all()),'client_groups_disjoint':True,'source_future_last_hour':148*24,'validation_last_hour':190*24,'test_first_hour':218*24+1,'strict_temporal_order':148*24<190*24<218*24+1,'normalizer_uses_history_only':True,'test_client_count':20,'test_days':28,'test_hour_points_per_client':28*24,'normalizer_min':min(x['past_mean'] for x in windows),'normalizer_max':max(x['past_mean'] for x in windows)}
(p/'数据/隔离审计_R1.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
