from paper_helpers import project
from pathlib import Path
import urllib.request,zipfile,json,hashlib,pandas as pd,numpy as np,datetime
p=project(2);data=p/'数据';data.mkdir(exist_ok=True)
url='https://archive.ics.uci.edu/static/public/321/electricityloaddiagrams20112014.zip';zpath=data/'electricityloaddiagrams20112014.zip'
if not zpath.exists():
 print('Downloading UCI data',flush=True);urllib.request.urlretrieve(url,zpath)
print('Downloaded',zpath.stat().st_size,flush=True)
with zipfile.ZipFile(zpath) as z:
 name=next(n for n in z.namelist() if n.endswith('LD2011_2014.txt') and '__MACOSX' not in n)
 pieces=[]
 with z.open(name) as f:
  for chunk in pd.read_csv(f,sep=';',decimal=',',chunksize=12000,usecols=list(range(61))):
   dates=pd.to_datetime(chunk.iloc[:,0]);part=chunk.loc[(dates>='2013-01-01')&(dates<'2013-09-01')].copy()
   if len(part):part.iloc[:,0]=pd.to_datetime(part.iloc[:,0]);pieces.append(part)
 d=pd.concat(pieces,ignore_index=True);d.iloc[:,0]=pd.to_datetime(d.iloc[:,0]);d=d.set_index(d.columns[0]);d.index=pd.DatetimeIndex(d.index)
 # Labels describe Portuguese local time. Shift endpoints back 15 minutes to align hourly interval means.
 d.index=d.index-pd.Timedelta(minutes=15);hour=d.resample('h').mean();hour=hour.loc['2013-01-01':'2013-08-30 23:00:00'];hour.to_csv(data/'hourly_60clients.csv',index_label='timestamp',float_format='%.9g')
 stats={'source':url,'dataset':'ElectricityLoadDiagrams20112014','creator':'Artur Trindade','donated':'2015-03-12','doi':'10.24432/C58C86','license':'CC BY 4.0','retrieved':datetime.datetime.now().isoformat(),'archive_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'rows':len(hour),'clients':list(hour.columns),'nan_count':int(hour.isna().sum().sum()),'min_kW':float(hour.min().min()),'max_kW':float(hour.max().max()),'zero_fraction_per_client':(hour.eq(0).mean()).to_dict(),'shift':'timestamp minus 15 minutes, hourly mean, no interpolation','source_note':'UCI values are kW; do not divide by 4 for hourly average power. DST correction retained as encoded by source.'}
 (data/'source.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(stats,ensure_ascii=False,indent=2),flush=True)
