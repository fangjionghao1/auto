function load_experiment(mode)
if nargin<1,mode='main';end
root=pwd;if ~isfolder(fullfile(root,mode)),mkdir(mode);end
D=readmatrix(fullfile(root,'..','数据','hourly_60clients.csv'));cd(mode);diary('run.log');fprintf('Start %s\n',string(datetime));
p=struct('source',1:30,'valid',31:40,'target',41:60,'preDays',4:120,'validEnd',148,'validTest',149:162,'targetEnd',190,'testDays',191:218,'budgets',[7 14 28],'seeds',[101 202 303],'epochs',30,'batch',128,'temperature',.2,'ridgeGrid',logspace(-4,2,7));
if strcmp(mode,'pilot'),p.source=1:5;p.valid=6:8;p.target=9:12;p.preDays=4:20;p.validEnd=27;p.validTest=28:35;p.targetEnd=42;p.testDays=43:49;p.budgets=7;p.seeds=42;p.epochs=3;end
save('params.mat','p');fid=fopen('env.txt','w');fprintf(fid,'%s\n%s',version,evalc('ver'));fclose(fid);
[XP,~,~,~]=windows(D,p.source,p.preDays);names={'Yesterday','RawRidge','RandomFeatures','Contrastive','SupervisedMLP'};pred=[];rawRows=[];stats=[];chosen=[];
for si=1:numel(p.seeds)
 rng(p.seeds(si));net=dlnetwork([featureInputLayer(72,Normalization='none');fullyConnectedLayer(64);tanhLayer;fullyConnectedLayer(16)]);randomNet=net;av=[];av2=[];iter=0;losslog=zeros(p.epochs,1);
 fn=sprintf('encoder_%d.mat',p.seeds(si));
 if exist(fn,'file'),load(fn,'net','randomNet','losslog');else
 for ep=1:p.epochs
  ord=randperm(size(XP,1));ls=[];
  for a=1:p.batch:numel(ord)
   ids=ord(a:min(a+p.batch-1,numel(ord)));x=single(XP(ids,1:72)');x1=augment(x);x2=augment(x);iter=iter+1;
   [loss,grad]=dlfeval(@contrast,net,dlarray(x1,'CB'),dlarray(x2,'CB'),p.temperature);[net,av,av2]=adamupdate(net,grad,av,av2,iter,.001);ls(end+1)=double(extractdata(loss));
  end
  losslog(ep)=mean(ls);
 end
 save(fn,'net','randomNet','losslog');end
 fprintf('Pretrain seed %d loss %.5f -> %.5f at %s\n',p.seeds(si),losslog(1),losslog(end),string(datetime));
 for bi=1:numel(p.budgets)
  budget=p.budgets(bi);[XV,YV,BV,MV]=windows(D,p.valid,p.validEnd-budget+1:p.validEnd);[XQ,YQ,BQ,MQ]=windows(D,p.valid,p.validTest);
  [XT,YT,BT,MT]=windows(D,p.target,p.targetEnd-budget+1:p.targetEnd);[XE,YE,BE,ME]=windows(D,p.target,p.testDays);out=zeros(size(YE,1),24,5);out(:,:,1)=BE;
  for method=2:4
   FV=features(XV,method,net,randomNet);FQ=features(XQ,method,net,randomNet);FT=features(XT,method,net,randomNet);FE=features(XE,method,net,randomNet);err=zeros(numel(p.ridgeGrid),1);
   for g=1:numel(p.ridgeGrid),W=ridgefit(FV,YV-BV,p.ridgeGrid(g));err(g)=mean((BQ+FQ*W-YQ).^2,'all');end
   [~,gi]=min(err);lam=p.ridgeGrid(gi);W=ridgefit(FT,YT-BT,lam);out(:,:,method)=BE+FE*W;chosen=[chosen; p.seeds(si) budget method lam];
  end
  rng(p.seeds(si));layers=[featureInputLayer(74,Normalization='none');fullyConnectedLayer(64);tanhLayer;fullyConnectedLayer(16);fullyConnectedLayer(24);regressionLayer];
  opts=trainingOptions('adam',MaxEpochs=p.epochs,MiniBatchSize=32,InitialLearnRate=.001,Shuffle='every-epoch',Verbose=false,Plots='none',ExecutionEnvironment='cpu');
  sup=trainNetwork(single(XT),single(YT-BT),layers,opts);out(:,:,5)=BE+double(predict(sup,single(XE)));save(sprintf('supervised_%d_%d.mat',p.seeds(si),budget),'sup');
  save(sprintf('pred_%d_%d.mat',p.seeds(si),budget),'out','YE','BE','ME','XT','YT','BT','XE');
  n=size(YE,1);rows=zeros(n*24*5,9);pos=0;
  for method=1:5
   for c=p.target
    ix=ME(:,1)==c;delta=out(ix,:,method)-YE(ix,:);stats=[stats;p.seeds(si) budget method c sqrt(mean(delta.^2,'all')) mean(abs(delta),'all')];
   end
   for i=1:n,ii=pos+(1:24);rows(ii,:)=[ones(24,1)*p.seeds(si) ones(24,1)*budget ones(24,1)*method ones(24,1)*ME(i,1) ones(24,1)*ME(i,2) (1:24)' YE(i,:)' out(i,:,method)' ones(24,1)*ME(i,3)];pos=pos+24;end
  end
  rawRows=[rawRows;rows];fprintf('Evaluated seed %d budget %d\n',p.seeds(si),budget);
 end
end
save('raw_results.mat','rawRows','stats','chosen','p','names','D','-v7.3');writetable(array2table(rawRows,'VariableNames',{'seed','budget_days','method','client','day','horizon_h','truth_relative','prediction_relative','past_mean_original'}),'raw_results.csv');writetable(array2table(stats,'VariableNames',{'seed','budget_days','method','client','NRMSE','NMAE'}),'metrics.csv');writetable(array2table(chosen,'VariableNames',{'seed','budget_days','method','lambda'}),'selected_lambda.csv');
summary=zeros(numel(p.budgets),5,2);for bi=1:numel(p.budgets),for m=1:5,ix=stats(:,2)==p.budgets(bi)&stats(:,3)==m;summary(bi,m,:)=mean(stats(ix,5:6),1);end,end
fid=fopen('summary.json','w');fprintf(fid,'%s',jsonencode(struct('metrics',summary,'names',{names},'budgets',p.budgets,'finished',char(datetime))));fclose(fid);disp(summary);diary off;cd(root);
end
function x=augment(x)
x=x.*(1+.03*randn(1,size(x,2),'single'))+.03*randn(size(x),'single');x(rand(size(x))<.05)=0;
end
function [loss,grad]=contrast(net,x1,x2,temp)
z1=stripdims(forward(net,x1));z2=stripdims(forward(net,x2));z1=z1./sqrt(sum(z1.^2,1)+1e-6);z2=z2./sqrt(sum(z2.^2,1)+1e-6);S=(z1'*z2)/temp;B=size(S,1);eyeB=eye(B,'single');
ls1=log(sum(exp(S-max(S,[],2)),2))+max(S,[],2);ls2=log(sum(exp(S-max(S,[],1)),1))+max(S,[],1);pos=sum(S.*eyeB,'all');loss=(sum(ls1)+sum(ls2)-2*pos)/(2*B);grad=dlgradient(loss,net.Learnables);
end
function [X,Y,B,M]=windows(D,clients,days)
n=numel(clients)*numel(days);X=zeros(n,74);Y=zeros(n,24);B=Y;M=zeros(n,3);k=0;
for c=clients,for day=days,k=k+1;t=(day-1)*24+1;hist=D(t-72:t-1,c);mu=mean(hist);assert(mu>0);h=hist'/mu-1;X(k,:)=[h sin(2*pi*day/7) cos(2*pi*day/7)];Y(k,:)=D(t:t+23,c)'/mu-1;B(k,:)=h(end-23:end);M(k,:)=[c day mu];end,end
end
function F=features(X,method,net,randomNet)
if method==2,F=[ones(size(X,1),1) X];else,if method==3,n=randomNet;else,n=net;end;z=double(extractdata(predict(n,dlarray(single(X(:,1:72)'),'CB'))))';F=[ones(size(X,1),1) X(:,49:74) z];end
end
function W=ridgefit(F,Y,lambda)
P=eye(size(F,2));P(1,1)=0;W=(F'*F+size(F,1)*lambda*P)\(F'*Y);
end
