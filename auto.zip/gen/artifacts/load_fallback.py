from paper_helpers import project
import urllib.request,json,base64,hashlib,gzip,pandas as pd,numpy as np
p=project(2);d=p/'数据';url='https://api.github.com/repos/laiguokun/multivariate-time-series-data/git/blobs/df158a9fff65428ece107200432a72c992d5e4e9'
req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json'})
print('Downloading verified Git blob via API',flush=True)
with urllib.request.urlopen(req,timeout=120) as f:r=json.loads(f.read())
b=base64.b64decode(r['content']);assert len(b)==17993794;assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['sha'];(d/'electricity_verified.txt.gz').write_bytes(b)
df=pd.read_csv(d/'electricity_verified.txt.gz',header=None);print('Full shape',df.shape,flush=True)
df.iloc[:6000,:60].to_csv(d/'hourly_60clients.csv',index=False,header=[f'client_{i:03d}' for i in range(1,61)],float_format='%.9g')
source={'source':url,'upstream':'https://archive.ics.uci.edu/dataset/321/electricityloaddiagrams20112014','doi':'10.24432/C58C86','creator':'Artur Trindade; hourly benchmark prepared by Guokun Lai et al.','license_upstream':'CC BY 4.0','sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':r['sha'],'shape':list(df.shape),'subset':'first 6000 hourly rows, first 60 columns, no performance-based selection','units':'Repository calls hourly consumption kWh, upstream values kW; exact aggregation scaling not independently verified. Use dimensionless per-window normalized load and errors only. No absolute kW claim.','time':'hour index retained; no invented timestamps','missing':int(df.iloc[:6000,:60].isna().sum().sum()),'min':float(df.iloc[:6000,:60].min().min()),'zero_fractions':df.iloc[:6000,:60].eq(0).mean().to_list(),'fallback':'Official UCI large download repeatedly interrupted; raw GitHub and HuggingFace transfers unavailable. Git blob API succeeded and hash validated.'}
(d/'source.json').write_text(json.dumps(source,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(source,indent=2),flush=True)
