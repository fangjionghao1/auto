function load_figures(mode)
if nargin<1,mode='main';end
root=pwd;cd(mode);load('raw_results.mat','rawRows','stats','p','names');if ~isfolder('图'),mkdir('图');end
set(groot,'defaultAxesFontSize',12,'defaultLineLineWidth',1.4);
f=figure('Visible','off','Position',[30 30 500 370]);hold on;sty={'k-','--',':','-.'};methods=[0 1 2 4];
for j=1:4,m=methods(j);ix=rawRows(:,1)==p.seeds(1)&rawRows(:,2)==7&rawRows(:,3)==max(m,1)&rawRows(:,4)==p.target(1)&rawRows(:,5)<=p.testDays(1)+6;q=rawRows(ix,:);tt=(q(:,5)-p.testDays(1))*24+q(:,6);if m==0,yy=q(:,7)+1;else,yy=q(:,8)+1;end;plot(tt,yy,sty{j});end
xlabel('Forecast hour in first test week');ylabel('Load / past-window mean');legend('Observed','Yesterday','Raw ridge','Contrastive','Location','southoutside','NumColumns',2);grid on;savefig(f,'图/fig1.fig');exportgraphics(f,'图/fig1.png',Resolution=200);close(f);
f=figure('Visible','off','Position',[30 30 500 370]);styles={'-o','--s',':d','-.^','-v'};mu=zeros(numel(p.budgets),5);sd=mu;
for m=1:5,for bi=1:numel(p.budgets),vals=zeros(numel(p.target),1);for ci=1:numel(p.target),ix=stats(:,2)==p.budgets(bi)&stats(:,3)==m&stats(:,4)==p.target(ci);vals(ci)=mean(stats(ix,5));end;mu(bi,m)=mean(vals);sd(bi,m)=std(vals);end,end
bb=bar(mu,'grouped');hold on;for m=1:5,errorbar(bb(m).XEndPoints,mu(:,m),sd(:,m),'k.','HandleVisibility','off');end;xticks(1:numel(p.budgets));xticklabels(string(p.budgets));xlabel('Labeled training days per client');ylabel('Normalized RMSE');legend(bb,names,'Location','southoutside','NumColumns',2);grid on;savefig(f,'图/fig2.fig');exportgraphics(f,'图/fig2.png',Resolution=200);close(f);
f=figure('Visible','off','Position',[30 30 500 370]);hold on;
for m=1:5,q=zeros(24,1);for h=1:24,ix=rawRows(:,2)==7&rawRows(:,3)==m&rawRows(:,6)==h;delta=rawRows(ix,8)-rawRows(ix,7);q(h)=sqrt(mean(delta.^2));end;plot(1:24,q,styles{m});end
xlabel('Forecast horizon (h)');ylabel('Pooled normalized RMSE');legend(names,'Location','southoutside','NumColumns',2);grid on;savefig(f,'图/fig3.fig');exportgraphics(f,'图/fig3.png',Resolution=200);close(f);
for j=1:3,f=openfig(fullfile('图',sprintf('fig%d.fig',j)),'invisible');assert(~isempty(findobj(f,'Type','axes')));close(f);end
cd(root);
end
