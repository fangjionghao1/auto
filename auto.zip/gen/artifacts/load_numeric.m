function load_numeric
load('R1/raw_results.mat','rawRows','p');load('R1/encoder_101.mat','net','futureNet','losslog');
np=sum(cellfun(@numel,net.Learnables.Value));fp=sum(cellfun(@numel,futureNet.Learnables.Value));assert(np==5712&&fp==2640);assert(all(isfinite(rawRows),'all'));assert(all(rawRows(:,9)>0));
assert(isempty(intersect(p.source,p.target))&&isempty(intersect(p.valid,p.target)));assert(max(p.validTest)<min(p.testDays));
out=struct('history_parameters',np,'future_parameters',fp,'finite_predictions',true,'positive_normalizers',true,'customer_groups_disjoint',true,'validation_precedes_test',true,'loss_seed101_first',losslog(1),'loss_seed101_last',losslog(end));
for j=1:3,f=openfig(fullfile('R1','图',sprintf('fig%d.fig',j)),'invisible');assert(~isempty(findobj(f,'Type','axes')));close(f);end
fid=fopen('numeric_check.json','w');fprintf(fid,'%s',jsonencode(out));fclose(fid);disp(out);
end
