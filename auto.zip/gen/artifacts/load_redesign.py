from paper_helpers import project
from pathlib import Path
import shutil,json
p=project(2);sim=p/'仿真';old=sim/'main'
shutil.copy2(sim/'load_experiment.m',old/'load_experiment_R0.m');shutil.copy2(p/'独立复算.json',old/'独立复算_R0.json');shutil.copy2(p/'独立复算.csv',old/'独立复算_R0.csv');shutil.copy2(p/'实验设计.md',old/'实验设计_R0.md')
s=(sim/'load_experiment.m').read_text(encoding='utf-8').replace('function load_experiment(mode)','function load_predictive(mode)').replace("mode='main'","mode='R1'")
s=s.replace("'preDays',4:120,'validEnd',148,'validTest',149:162,'targetEnd',190,'testDays',191:218","'preDays',4:148,'validEnd',176,'validTest',177:190,'targetEnd',218,'testDays',219:246")
s=s.replace('[XP,~,~,~]=windows','[XP,YP,~,~]=windows')
s=s.replace('randomNet=net;av=[];av2=[];iter=0;','randomNet=net;futureNet=dlnetwork([featureInputLayer(24,Normalization=\'none\');fullyConnectedLayer(64);tanhLayer;fullyConnectedLayer(16)]);av=[];av2=[];fv=[];fv2=[];iter=0;')
s=s.replace("load(fn,'net','randomNet','losslog')","load(fn,'net','randomNet','futureNet','losslog')")
s=s.replace("x1=augment(x);x2=augment(x)","x1=augment(x);x2=augment(single(YP(ids,:)'))")
s=s.replace("[loss,grad]=dlfeval(@contrast,net,dlarray(x1,'CB'),dlarray(x2,'CB'),p.temperature);[net,av,av2]=adamupdate(net,grad,av,av2,iter,.001);","[loss,grad,fg]=dlfeval(@contrast,net,futureNet,dlarray(x1,'CB'),dlarray(x2,'CB'),p.temperature);[net,av,av2]=adamupdate(net,grad,av,av2,iter,.001);[futureNet,fv,fv2]=adamupdate(futureNet,fg,fv,fv2,iter,.001);")
s=s.replace("save(fn,'net','randomNet','losslog')","save(fn,'net','randomNet','futureNet','losslog')")
s=s.replace('function [loss,grad]=contrast(net,x1,x2,temp)','function [loss,grad,fg]=contrast(net,futureNet,x1,x2,temp)').replace('stripdims(forward(net,x2))','stripdims(forward(futureNet,x2))').replace('grad=dlgradient(loss,net.Learnables);','[grad,fg]=dlgradient(loss,net.Learnables,futureNet.Learnables);')
(sim/'load_predictive.m').write_text(s,encoding='utf-8')
(p/'重设计记录.md').write_text('''# 重设计 R0→R1
R0真实三种子结果：七日预算对比NRMSE0.17057，随机0.16938；配对收益-0.001190，95%区间[-0.002674,0.000253]，20客户仅7客户改善。未通过预设自监督收益门禁，不能只以优于昨日复制声明成功。R0源码、网络、原始记录、独立复算全部保留于main。
根因假设：同窗口增强判别可突出实例差异，但不强制保留预测未来日所需的模式；下降的对比损失不是预测收益。R1改为历史72h编码与后续24h编码的交叉视图对比，两个分支分别72→64→16和24→64→16，未来分支只在源数据预训练中使用，推理丢弃。损失仍为对称跨视图InfoNCE，未加入目标客户未来信息。
冻结R1：源客户1—30，源日4—148；验证客户31—40支持截至176日、验证177—190日；目标客户41—60支持截至218日、测试219—246日。R0已观察的191—218日只作为新的过去历史，不再称保留测试。新测试此前未评价。预算7/14/28、三种子101/202/303、30轮、温度0.2及全部基线不变。未来源片段同样用其历史均值归一化，保持因果尺度。没有客户按性能剔除。
检验仍要求七日对比表征相对随机表征改善，并优于昨日；不预设改善幅度。若失败再按同一规则记录，最多三次完整重设计。
''',encoding='utf-8')
(p/'实验设计.md').write_text((p/'实验设计.md').read_text(encoding='utf-8')+'\n当前有效设计为重设计记录.md中的R1，原R0只作历史。\n',encoding='utf-8')
print('R1 saved')
