from paper_helpers import project
from pathlib import Path
import json,urllib.request,concurrent.futures,datetime,hashlib,shutil,numpy as np,pandas as pd
p=project(2);(p/'仿真').mkdir(exist_ok=True)
def w(n,s):(p/n).write_text(s,encoding='utf-8')
w('目标配置卡.md','''# 目标配置卡
EI会议研究稿，中英双稿，具体会议及作者未提供，不称投稿就绪。学科：负荷预测、时间序列、自监督学习。原题保留作项目身份，稿题拟为对比表征驱动的电表少样本负荷预测。3图2表、10条2021—2026带DOI研究文献，数据来源另在正文明确归属及2015年DOI，不伪改数据集年份。中文约4000汉字且≤4500；原生OMML、页码。没有材料目录。正式签署依规则须FJH，未取得。
''')
w('实验设计.md','''# 冻结实验设计 R0
2026-10-08。真实公开UCI衍生小时基准，数据来源与哈希见数据/source.json。固定前60列、前6000行，不能按测试效果选客户。保留真实零值，不补插、不聚合客户、不虚构日历时间。
每24行称一日，首行为小时索引1，日d起点(d-1)*24+1。输入过去72h，预测随后24h；每个窗口按过去72h均值归一化为负荷/均值-1，未来目标同尺度。回归修正前一日对应24h序列。输入仅用已知历史；无天气和未来负荷。所有输出是无量纲相对负荷，绝不冒充kW。周相位按记录日索引的周期sin/cos，不声称真实周几。
预训练客户1—30、日4—120，只使用历史窗口，无预测标签。验证客户31—40，支持样本为截至日148的最后7/14/28个日样本，验证日149—162。目标客户41—60，支持样本为截至日190的最后7/14/28个日样本，保留测试日191—218共28日。验证全部早于目标测试，客户互斥。数据本有更长历史，但模型按预算仅看指定标签和必要72h上下文；测试期间每天可访问当日截止前已观测历史，参数不更新。少样本指每客户的预测训练日数，不指人工标注费用。
编码器72→64(tanh)→16；批128、30轮、Adam0.001；温度0.2。同一历史窗口的两个视图为0.03标准差抖动、0.03幅值缩放、5%点掩码到均值；无时间置乱和未来标签。对称跨视图InfoNCE，同批其它窗口作为负例。随机初始化种子101/202/303，全部保留。
模型：昨日复制；72h原始特征+周相位的岭回归；随机冻结编码器16维+昨日24h+周相位的岭回归；对比预训练冻结编码器同样特征的岭回归；目标支持集监督MLP(74→64→16→24)，30轮。各学习模型都预测相对昨日的残差，岭系数固定候选1e-4—1e2七项，仅验证客户调参，逐预算逐模型同样搜索。训练目标与归一化对照一致。
核心检验：7日预算下对比表征相对同结构随机表征出现可复算误差降低，并相对昨日基线有预测收益；强原始岭和监督模型结果照实保留，不要求全指标统治。若自监督无增益须分析和重设计，不能只改文字。
指标：每客户合并28日×24h后的归一化RMSE和MAE，再对客户、种子等权平均。配对以客户为单位，先种子平均再bootstrap5000，避免重叠历史被当独立样本。图1第一目标客户固定首测试周；图2各预算均值及客户标准差；图3逐预测小时误差。表1数据设置，表2七日总体指标。保留全部输出与失败。
先导：只使用主实验源客户中的1—12，较早日段，不能查看目标41—60测试数据；种子42、3轮。主实验冻结前先检查零值、有限数、归一化尺度、正负样本数和数据时序。
''')
w('论文框架.md','''# 论文框架
1 引言约650字：新客户短历史问题、迁移/对比学习现状、区分少标签与人工标签成本。
2 任务与数据约850字：公开电表来源、客户时间隔离、相对负荷定义。
3 方法约1000字：视图构造、对比损失、冻结表征、残差岭及公平基线。
4 实验约1200字：三预算三种子、表1/表2、图1/2/3、配对统计与局部失败。
5 结论约300字：只回应实际主实验。总目标4000汉字。摘要结果留待主实验。
''')
d=pd.read_csv(p/'数据/hourly_60clients.csv').to_numpy();means=np.array([np.mean(d[(day-1)*24-72:(day-1)*24,:30],axis=0) for day in range(4,121)]);assert np.all(np.isfinite(d)) and np.all(means>0)
w('先导数量级.json',json.dumps({'data_shape':list(d.shape),'pretrain_windows':117*30,'support_windows_7d':20*7,'validation_windows':10*14,'test_windows':20*28,'min_pretrain_past_mean':float(means.min()),'max_pretrain_past_mean':float(means.max()),'label_context_hours':72,'test_start_hour':190*24+1,'last_validation_target_hour':162*24,'daily_samples_not_independent_due_to_overlap':True},indent=2))
dois=['10.1016/j.engappai.2025.110980','10.3390/en18030742','10.1002/tee.24017','10.24963/ijcai.2021/324','10.1609/aaai.v36i8.20881','10.1609/aaai.v38i12.29299','10.1016/j.knosys.2024.112652','10.1109/TPAMI.2024.3387317','10.1609/aaai.v37i9.26317','10.1016/j.egyai.2022.100141']
def fetch(d):
 try:return {'doi':d,'checked_at':datetime.datetime.now().isoformat(),'metadata':json.loads(urllib.request.urlopen('https://api.crossref.org/works/'+d,timeout=40).read())['message']}
 except Exception as e:return {'doi':d,'error':str(e)}
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=3).map(fetch,dois));w('文献元数据.json',json.dumps(r,ensure_ascii=False,indent=2))
for q in r:print(q['doi'],q.get('metadata',{}).get('title'),q.get('error'))
shutil.copy2(Path(__file__).with_name('load_experiment.m'),p/'仿真/load_experiment.m')
s=json.loads((p/'.paper-pipeline/status.json').read_text(encoding='utf-8'));s.update(phase='pilot',progress='执行中',prompt_sha256=hashlib.sha256((p/'final_prompt.md').read_bytes()).hexdigest(),reason='真实公开数据已取得，冻结客户/时间划分，准备先导');w('.paper-pipeline/status.json',json.dumps(s,ensure_ascii=False,indent=2))
