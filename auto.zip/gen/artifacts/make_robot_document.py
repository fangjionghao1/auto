from pathlib import Path
import json,re
root=Path(__file__).parent
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
s=json.loads((p/'仿真/R1/summary.json').read_text(encoding='utf-8'));v=json.loads((p/'独立复算.json').read_text(encoding='utf-8'))
rm=s['rmse'];ma=s['mae']; gain=(rm[1]-rm[5])/rm[1]*100
assert gain>0,'No nominal improvement; do not generate a positive manuscript.'
cn=['保持值','名义气动模型','岭回归','LSTM','直接Transformer','残差Transformer']
en=['Persistence','Nominal model','Ridge','LSTM','Direct Transformer','Residual Transformer']
refs=[]
for i,r in enumerate(json.loads((p/'文献元数据.json').read_text(encoding='utf-8')),1):
    m=r['metadata'];au=m.get('author',[]);authors=', '.join(a.get('family','')+' '+a.get('given','') for a in au[:3])+(', et al' if len(au)>3 else '')
    year=m.get('published-print',m['published'])['date-parts'][0][0]
    refs.append(f"[{i}] {authors}. {m['title'][0]}. {m.get('container-title',[''])[0]}, {year}, {m.get('volume','')}{'('+m['issue']+')' if m.get('issue') else ''}: {m.get('page',m.get('article-number',''))}. DOI: {r['doi']}.")
times=s['trainSeconds'];mean_times=[sum(x)/len(x) for x in times]
values=dict(res_rmse=f'{rm[5]:.4f}',nom_rmse=f'{rm[1]:.4f}',ridge_rmse=f'{rm[2]:.4f}',lstm_rmse=f'{rm[3]:.4f}',direct_rmse=f'{rm[4]:.4f}',gain=f'{gain:.2f}',tau=f"{s['tau']:.3f}",times='、'.join(f'{x:.1f}' for x in mean_times),references='\n\n'.join(refs),table_rows='\n'.join(f'| {name} | {r:.4f} | {m:.4f} |' for name,r,m in zip(cn,rm,ma)),table_rows_en='\n'.join(f'| {name} | {r:.4f} | {m:.4f} |' for name,r,m in zip(en,rm,ma)))
if rm[2]<rm[5]:
 values.update(finding='残差校正相对名义动态提供了误差收益，但同信息岭回归仍有更低误差',finding_en='Residual correction improves nominal dynamics, while the same-information ridge baseline remains more accurate.',comparison=f'残差模型优于名义递推，但未超过岭回归，因而不能将结果表述为注意力结构全面优越。相对名义模型的改善为{gain:.2f}%，对强线性基线的差距仍需解释',comparison_en=f'The residual model improves the nominal prediction by {gain:.2f}% but does not outperform ridge regression. The results therefore do not establish universal superiority of attention.',conclusion='相对名义动态的误差得到降低，但岭回归仍是本组数据中的更强对照',conclusion_en='Error is reduced relative to nominal dynamics, but ridge regression remains a stronger comparator on these data.')
else:
 values.update(finding='残差校正改善了名义动态预测，并在本组仿真中低于同信息岭回归误差',finding_en='Residual correction improves nominal prediction and obtains a lower error than the same-information ridge baseline on these simulations.',comparison=f'残差模型相对名义模型的改善为{gain:.2f}%，其RMSE也低于岭回归；这一收益来自固定测试集合的完整统计',comparison_en=f'The residual model improves nominal prediction by {gain:.2f}% and has a lower RMSE than ridge regression on the complete frozen test set.',conclusion='相对名义递推和同信息岭回归均观察到误差改善',conclusion_en='Lower error is observed relative to both nominal prediction and same-information ridge regression.')
ci=v['paired_bootstrap_95CI']; values.update(paired=f"将三个网络种子的误差先在每条轨迹内平均后，48条轨迹中有{v['better_trajectories']}条相对名义模型改善；配对平均差为{v['paired_mean_gain_kPa']:.4f} kPa，轨迹自助法95%区间为[{ci[0]:.4f}, {ci[1]:.4f}] kPa",paired_en=f"After averaging seeds within each trajectory, {v['better_trajectories']} of 48 trajectories improve over the nominal model. The mean paired difference is {v['paired_mean_gain_kPa']:.4f} kPa, with a trajectory-bootstrap 95% interval of [{ci[0]:.4f}, {ci[1]:.4f}] kPa.")
if rm[5]<rm[4]:values.update(ablation='两者的差异支持在当前训练预算下保留名义响应先验，不能据此排除直接模型在其他预算下的可能收益',ablation_en='This difference supports retaining nominal dynamics under the tested training budget; it does not rule out a direct model advantage under a different budget.')
else:values.update(ablation='残差结构未优于直接结构，因此没有证据将其称为最佳融合方式',ablation_en='The residual structure does not improve upon the direct structure and is not established as the best fusion design.')
h=v['horizon_rmse']['6'];h0=h.get('1');h8=h.get('8');values.update(horizon=f'残差方法在第一步和第八步的合并RMSE分别为{h0:.4f}和{h8:.4f} kPa',horizon_en=f'The pooled residual-model RMSE is {h0:.4f} kPa at the first step and {h8:.4f} kPa at the eighth step.')
for lang in ['zh','en']:
 t=(root/f'robot_manuscript_{lang}.template').read_text(encoding='utf-8')
 for key,val in values.items():t=t.replace('{{'+key+'}}',str(val))
 assert '{{' not in t
 t=t.replace('仿真/图/','仿真/R1/图/').replace('其中$~ p$','其中$\\tilde p$')
 if lang=='en':t=t.replace('、',', ')
 (p/f'论文_{lang}.md').write_text(t,encoding='utf-8')
 body=t.split('## 1 ')[1].split('## 参考文献' if lang=='zh' else '## References')[0]
 body=re.sub(r'\$\$.*?\$\$','',body,flags=re.S);body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','图','表','!','Figure ','Table ')))
 print(lang,'Chinese chars',len(re.findall('[\u4e00-\u9fff]',body)),'words',len(body.split()))
(p/'成文数值.json').write_text(json.dumps(values,ensure_ascii=False,indent=2),encoding='utf-8')
