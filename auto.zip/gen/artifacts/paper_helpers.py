from pathlib import Path
import json,re,zipfile,hashlib
from lxml import etree
def project(i):return Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][i]['path'])
def references(p):
 rows=json.loads((p/'文献元数据.json').read_text(encoding='utf-8'));out=[]
 for i,r in enumerate(rows,1):
  m=r['metadata'];authors=m.get('author',[]);a=', '.join((x.get('family','')+' '+x.get('given','')).strip() for x in authors[:3]);a+=', et al.' if len(authors)>3 else ''
  title=m['title'][0].replace('time�Cfrequency','time–frequency');year=m['published']['date-parts'][0][0];vol=m.get('volume','');issue=m.get('issue','');pages=m.get('page',m.get('article-number',''))
  if pages=='20220113-20220113':pages='20220113'
  kind='C' if m.get('type')=='proceedings-article' or 'Proceedings' in m['container-title'][0] else 'J'
  out.append(f"[{i}] {a}. {title}[{kind}]. {m['container-title'][0]}, {year}"+(f', {vol}' if vol else '')+(f'({issue})' if issue else '')+f': {pages}. DOI: {r["doi"]}')
 return '\n\n'.join(out)
def audit(p):
 out={}
 for lang in ['zh','en']:
  text=(p/f'论文_{lang}.md').read_text(encoding='utf-8');body=text.split('## 1 ',1)[1].split('## 参考文献' if lang=='zh' else '## References')[0]
  body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','![')) and not re.match(r'^(?:图|表)\d+\s|^(?:Figure|Table) \d+ ',x))
  with zipfile.ZipFile(p/f'论文_{lang}.docx') as z:
   xml=etree.fromstring(z.read('word/document.xml')); ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
   out[lang]={'body_hanzi':len(re.findall('[\u4e00-\u9fff]',body)),'body_words':len(re.findall(r'\b\w+\b',body)),'omml':len(xml.xpath('//m:oMath',namespaces=ns)),'tables':len(xml.xpath('//w:tbl',namespaces=ns)),'images':len(xml.xpath('//a:blip',namespaces=ns)),'numbered_equations':re.findall(r'\\tag\{(\d+)\}',text),'controls':[ord(c) for c in text if ord(c)<32 and c not in '\n\t\r'],'references':len(re.findall(r'^\[\d+\] ',text,re.M))}
 (p/'结构核验.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');return out
