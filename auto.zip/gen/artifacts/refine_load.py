from paper_helpers import project
import re
p=project(2)
zh={
'归属、版本对象哈希、下载文件哈希及截取步骤随复现材料保存。':'实际使用的[小时基准仓库](https://github.com/laiguokun/multivariate-time-series-data)提供可追溯的下载对象。固定列号只是样本选择规则，不代表随机抽样，因此不能据此估计所有电表客户的总体平均性能。归一化减少不同规模之间的直接量级差异，但不会消除客户行为、季节变化和异常负荷带来的异质性。',
'调参不访问后续测试期。':'划分先于窗口提取，保证同一客户不会同时承担源域预训练和目标评估角色。验证客户的支持集用于拟合候选输出头，验证后续日用于选择惩罚系数；确定系数后，在目标支持集重新拟合头部。验证头的回归权重不直接搬到目标客户，因而参数选择与最终目标拟合是两个分开的步骤。',
'不能作为输入或重新训练标签。':'这一滚动协议允许已发生的测试观测成为后续日期的历史，与每日更新输入的实际预测流程一致。它不是在第一个测试日一次性预测未来四周，也不能用四周之后才可获得的信息补齐早期输入。所有方法遵守同一信息时点，因此昨日复制同样使用预测起点之前的真实前一日负荷。',
'求解采用线性方程而不是数值显式求逆。':'惩罚项乘以支持样本数，使不同预算下的系数都对应平均损失尺度，避免仅因样本数量增加而隐式改变正则强度。常数项不惩罚，用于吸收客户组的整体残差偏置。候选范围对原始岭、随机表征和对比表征一致，每种方法都独立通过相同验证规则选择，不把对比方法的最佳参数强加给基线。',
'也不能把其效果归因于自监督学习。':'对比目标中的表示先归一化再求相似度，输出头则使用编码器原始16维数值，这一约定对随机和训练后编码器保持一致。预训练过程中全部源片段都参与优化，没有按照目标误差筛选邻居客户。由此得到的是共享表征的平均效果，而不是为某个目标客户事后挑选最相似源任务的结果。'
}
q=p/'论文_zh.md';s=q.read_text(encoding='utf-8')
for a,b in zh.items():assert a in s;s=s.replace(a,a+b)
q.write_text(s,encoding='utf-8')
q=p/'论文_en.md';s=q.read_text(encoding='utf-8')
s=s.replace('Attribution, Git-object identity, file hashes, and extraction steps accompany the reproduction materials.','Attribution, Git-object identity, file hashes, and extraction steps accompany the reproduction materials. The actual [hourly benchmark repository](https://github.com/laiguokun/multivariate-time-series-data) provides the traceable download object. Selecting fixed columns is not random population sampling, and normalization does not remove behavioral or seasonal heterogeneity.')
s=s.replace('Thus, customer sets are disjoint and tuning precedes the new test period.','Thus, customer sets are disjoint and tuning precedes the new test period. Candidate heads are fitted on validation-customer support and scored on their later validation days. After selecting a penalty, a new head is fitted on target support; validation regression weights are not transferred to the target group.')
s=s.replace('but never the subsequent target or test-period parameter updates.','but never the subsequent target or test-period parameter updates. Already observed test days may become history for later origins. This is not a single forecast of the entire four-week test period made at its beginning; every baseline follows the same daily information cutoff.')
s=s.replace('Computation solves a linear system instead of forming an explicit numerical inverse.','Computation solves a linear system instead of forming an explicit numerical inverse. Multiplication by support size makes the penalty correspond to an average-loss scale across budgets. The intercept is unpenalized. Raw, random-feature, and contrastive ridge heads independently select from the same candidate grid and validation rule.')
s=s.replace('isolating the effect of pretraining.','isolating the effect of pretraining. Similarity uses normalized representations, while the regression head receives the original 16 encoder outputs in both learned and random cases. All source pairs participate; no source customers are selected by target test error.')
q.write_text(s,encoding='utf-8')
for lang in ['zh','en']:
 q=p/f'论文_{lang}.md';s=q.read_text(encoding='utf-8');s=s.replace(r'\mu_{c,t}=\frac{1}{72}\sum_{j=1}^{72}l_{c,t-j},\quad x_{c,t,j}=\frac{l_{c,t-j}}{\mu_{c,t}}-1',r'\begin{aligned}\mu_{c,t}&=\frac{1}{72}\sum_{j=1}^{72}l_{c,t-j},\\x_{c,t,j}&=\frac{l_{c,t-j}}{\mu_{c,t}}-1.\end{aligned}');s=s.replace(r's_{ij}=\frac{z_i^\mathsf{T}v_j}{\|z_i\|\|v_j\|},\quad P_{ij}=\frac{e^{s_{ij}/T}}{\sum_k e^{s_{ik}/T}}',r'\begin{aligned}s_{ij}&=\frac{z_i^\mathsf{T}v_j}{\|z_i\|\|v_j\|},\\P_{ij}&=\frac{e^{s_{ij}/T}}{\sum_k e^{s_{ik}/T}}.\end{aligned}');q.write_text(s,encoding='utf-8')
 body=s.split('## 1 ',1)[1].split('## 参考文献' if lang=='zh' else '## References')[0];body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','![')) and not re.match(r'^(?:图|表)\d+\s|^(?:Figure|Table) \d+ ',x));print(lang,len(re.findall('[\u4e00-\u9fff]',body)),len(re.findall(r'\b\w+\b',body)))
