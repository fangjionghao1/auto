from pathlib import Path
import json
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
for lang in ['zh','en']:
 q=p/f'论文_{lang}.md';s=q.read_text(encoding='utf-8')
 s=s.replace(r'$hat\tau$',r'$\hat\tau$')
 s=s.replace(r',\quad C_i=V_i+(p_a+p_i)\frac{dV_i}{dp_i}. \tag{1}',r'. \tag{1}')
 s=s.replace(r',\quad b_{i,t}=\tilde p_{i,t}. \tag{4}',r'. \tag{4}')
 if lang=='zh':
  s=s.replace('其中$p_a$为大气压',r'其中$C_i=V_i+(p_a+p_i)dV_i/dp_i$为有效电容，$p_a$为大气压')
  s=s.replace(r'其中$\tilde p$表示带噪观测',r'初值$b_{i,t}=\tilde p_{i,t}$，$\tilde p$表示带噪观测')
  s=s.replace('下一步可在压力记录、阀门计划和接触事件同步采集条件下检验跨设备迁移，并将预测误差与动作协调指标建立联系。','')
  s=s.replace('这里保留完整失败轨迹和所有模型输出，使后续研究能够在相同记录上定位偏差，并判断增加模型复杂度是否带来足够收益。','全部轨迹与输出均保留，便于后续定位偏差。')
 else:
  s=s.replace('Here $p_a$ is atmospheric pressure',r'Here $C_i=V_i+(p_a+p_i)dV_i/dp_i$ is the effective capacitance and $p_a$ is atmospheric pressure')
  s=s.replace('This model captures the dominant direction',r'The initial condition is $b_{i,t}=\tilde p_{i,t}$. This model captures the dominant direction')
 q.write_text(s,encoding='utf-8')
