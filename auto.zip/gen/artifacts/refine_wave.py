from paper_helpers import project
p=project(1)
q=p/'论文_zh.md';s=q.read_text(encoding='utf-8')
insertions={
'各事件分别抽取参数，覆盖正、负反射而非仅生成单一理想阶跃。':'在该定义下，幅值始终以到达端为参考，无需把传播前后的电压数值混用。按180 m/μs的示例波速，设定到达时间对应540—1260 m传播距离，但距离只用于数量级核对，不进入网络标签或定位评价。反射延迟单独抽取，代表接头或端部反射的简化影响，不能直接解释为某一固定线路拓扑。',
'模型不包含饱和、量化和参数标定误差，后续结论均在该测量假设下解释。':'具体混合时，白噪声和有色噪声的系数分别为0.7和0.3，先合成再归一化均方，因此系数不是两个分量最终能量占比。该设置使噪声具有部分时间相关性，避免把全部误差都归结为可通过简单平均消除的独立扰动。三个噪声档位在划分内部保持均衡，结果不由某个低噪声档位的大样本量主导。',
'不用测试集寻找最优参数。':'最终验证集选择的正则系数为0.1，全部测试噪声档位共用该值。精确逆、正则逆和两个网络都获得同一真实时间常数，因而比较不包含某个方法额外获得测量参数的优势。正则逆输入也同时提供给直接网络，使结构比较集中于输出目标和训练尺度，而不是信息数量。',
'未验证在线因果处理或现场实时延迟。':'训练过程不使用定时标签，仅学习完整波形，所以后续定时收益是对固定提取器的间接改善。全记录均方损失同时约束前沿前的基线、上升过程和衰减尾部，避免只在局部波头附近优化而忽略整体电压恢复。卷积核共享使同一局部规律可作用于不同到达时刻，但这种平移特性并不消除边界填充或训练分布变化的影响。',
'避免把记录中的采样点视为独立试验。':'汇总时保留每个事件、每个种子及每个方法的对应关系，不先拼接全部波形再取一次平方根。前者衡量典型事件的平均误差，后者更受少数大误差事件影响，二者不是同一统计口径。本文表格、摘要和结论统一采用前者；分层结果也在各档位内先算事件指标，再进行平均。',
'整体判断以全部事件为准。':'首个事件在生成顺序固定后即确定，没有根据曲线接近程度另选展示对象。解析逆虽然能够精确补偿无噪测量链，但在存在噪声时不能把可逆性与稳定恢复等同。图示和后续总体指标共同检验这一差别，避免用单个平滑示例代替抗噪性证据。',
'不能将其总体均值误解为各工况均最优。':'相反，观测信号在三个档位的定时误差仍约为0.25 μs，说明仅降低噪声并不能消除测量链迟滞。两种卷积模型同时改善低噪声和高噪声下的误差，但这项结果依赖训练阶段覆盖的脉冲与带宽范围。对于高频细节完全落在噪声底以下的信号，学习输出可能更多反映训练先验，不能未经真值比较就视为真实恢复。'
}
for key,val in insertions.items():assert key in s;s=s.replace(key,key+val)
q.write_text(s,encoding='utf-8')
q=p/'论文_en.md';s=q.read_text(encoding='utf-8').replace('Test events are not used to tune this parameter.','Test events are not used to tune this parameter. The selected value is 0.1 and is shared across all test SNR levels. The exact inverse, regularized inverse, and both networks receive the same true time constant. The direct network also receives the regularized waveform, preventing an information-access advantage for the residual formulation.').replace('Events have independent noise realizations.','Events have independent noise realizations. White and colored components have mixing coefficients 0.7 and 0.3 before the combined noise is normalized; these coefficients are not final energy fractions.').replace('Causal online operation and field-device latency are not claimed.','Causal online operation and field-device latency are not claimed. Training uses complete waveform targets rather than timing labels, so the timing improvement is an indirect consequence of waveform reconstruction.').replace('Arrival amplitude and rise-time ranges parameterize attenuation and broadening.','Arrival amplitude and rise-time ranges parameterize attenuation and broadening. A reference speed of 180 m/μs maps the arrival interval to 540–1260 m for a scale check only; distance is not used as a training label or evaluated location result.')
q.write_text(s,encoding='utf-8')
for lang in ['zh','en']:
 q=p/f'论文_{lang}.md';s=q.read_text(encoding='utf-8')
 s=s.replace(r'g(s)=(1-e^{-s/t_r})e^{-s/t_d}\mathbf{1}_{s\geq0},\quad x(t)=A[g(t-t_0)+\rho g(t-t_0-\Delta)]',r'\begin{aligned}g(s)&=(1-e^{-s/t_r})e^{-s/t_d}\mathbf{1}_{s\geq0},\\x(t)&=A[g(t-t_0)+\rho g(t-t_0-\Delta)]\end{aligned}')
 s=s.replace(r'\hat X_\lambda(\omega)=\frac{H^*(\omega)Z(\omega)}{|H(\omega)|^2+\lambda},\quad H(\omega)=\frac{1-a}{1-ae^{-j\omega}}',r'\begin{aligned}\hat X_\lambda(\omega)&=\frac{H^*(\omega)Z(\omega)}{|H(\omega)|^2+\lambda},\\H(\omega)&=\frac{1-a}{1-ae^{-j\omega}}\end{aligned}')
 s=s.replace(r'\hat x^{D}=f_\theta([z,b,\tau]),\quad \hat x^{R}=b+c f_\theta([z,b,\tau]),\quad c=0.1\ {\rm kV}',r'\begin{aligned}\hat x^{D}&=f_\theta([z,b,\tau]),\\\hat x^{R}&=b+c f_\theta([z,b,\tau]),\\c&=0.1\ {\rm kV}\end{aligned}')
 q.write_text(s,encoding='utf-8')
