from pathlib import Path
import json,re,unicodedata,shutil
root=Path(__file__).parent
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
sim=p/'仿真/R1'
assert len(list(sim.glob('model_*.mat')))==9,'Training checkpoints incomplete'
log=unicodedata.normalize('NFKC',(sim/'run_main.log').read_text(encoding='utf-8',errors='replace'))
times=[[0.0]*3 for _ in range(3)];typ=seed=None
for line in log.splitlines():
 match=re.search(r'TRAIN type=(\d) seed=(\d+)',line)
 if match:typ=int(match[1])-1;seed=[101,202,303].index(int(match[2]))
 match=re.search(r'(\d\d):(\d\d):(\d\d)',line)
 if match and typ is not None:times[typ][seed]=int(match[1])*3600+int(match[2])*60+int(match[3])
assert all(v>0 for r in times for v in r)
(sim/'training_times.csv').write_text('\n'.join(','.join(map(str,r)) for r in times),encoding='utf-8')
shutil.copy2(sim/'robot_experiment.m',sim/'robot_experiment_training_original.m')
shutil.copy2(root/'robot_experiment.m',sim/'robot_experiment.m')
for name in ['robot_numeric_check.m','robot_figures.m']:shutil.copy2(root/name,sim/name)
(sim/'evaluation_resume.md').write_text('''# 评估续作说明\n训练完成后，原逐行增长的预测CSV构造有不必要的内存复制，终止评估并从九个已保存网络恢复。恢复时使用相同种子20261009重新生成相同数据，未修改参数、模型或测试集合。改用预分配数组导出。training_times.csv记录原日志末次显示的经过时间，秒级截断且略少于完整训练耗时；不作为论文中的精确训练计时证据。重新运行入口main会完整训练，resume只用于本次恢复。\n''',encoding='utf-8')
for lang in ['zh','en']:
 q=root/f'robot_manuscript_{lang}.template';s=q.read_text(encoding='utf-8')
 if lang=='zh':
  start=s.index('三次训练的平均耗时');end=s.index('下一步可在',start)
  s=s[:start]+'全部网络在同一主机CPU上执行，训练轮数、批量大小和验证频率一致。直接模型与残差模型采用相同宽度，因而本实验比较的是相同配置预算下的预测误差，没有证明残差结构具有训练成本优势。网络采用离线训练，控制器端到端周期未测量，因此不宣称已满足嵌入式实时部署要求。'+s[end:]
 else:
  start=s.index('Mean measured training times');end=s.index('A next experimental step',start)
  s=s[:start]+'All networks run on the same host CPU with identical epoch counts, batch sizes and validation frequencies. The direct and residual Transformers have the same encoder width. The experiment therefore compares prediction error under the specified configuration budget without establishing a training cost advantage. End to end deployment latency has not been measured, and embedded real time performance is not established. '+s[end:]
 q.write_text(s,encoding='utf-8')
print(sim)
