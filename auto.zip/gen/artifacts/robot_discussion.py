from pathlib import Path
import json,re
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
q=p/'论文_zh.md';s=q.read_text(encoding='utf-8');insert='''岭回归取得最低误差，说明在当前压力范围和预测时长内，带有完整历史及未来计划的线性映射已经能表达较多动态信息。本文的数据生成方程虽含非线性项，但短时工作区间可能接近局部线性，不能仅凭模型方程含有非线性就推断深度网络必然占优。对于本组工况，如果工程目标仅是降低预测误差，岭回归应作为优先比较对象；残差网络的证据在于相对名义递推的校正，而不是替代全部简单方法的必要性。

直接与残差网络的比较同时改变了输出分解和目标归一化尺度，因此该消融支持的是当前训练方案的整体比较，不能把全部差异单独归因于某一物理先验。若要进一步分离两者作用，应增加相同目标尺度的直接网络或零初始化输出等对照。本研究未开展这些附加试验，故不作唯一机制归因。所有网络均使用固定25轮预算，验证集选择可以减轻过拟合，但不能证明各网络均达到其最优可实现精度。

此外，本实验的主要压力范围、窗口长度和驱动周期均在设计阶段固定。不同供气设备、气管阻力或更强接触可能改变最佳模型排序，不能将当前误差排名扩展到未测试区间。这里保留完整失败轨迹和所有模型输出，使后续研究能够在相同记录上定位偏差，并判断增加模型复杂度是否带来足够收益。

'''
s=s.replace('## 5 结论',insert+'## 5 结论');q.write_text(s,encoding='utf-8')
q=p/'论文_en.md';s=q.read_text(encoding='utf-8');s=s.replace('## 5 Conclusion','''Ridge regression has the lowest error, indicating that the full history and known command schedule permit a linear mapping to explain much of the short horizon response. Nonlinear terms in the generating equations do not guarantee that a deep network will outperform a local linear approximation. If error alone determines the engineering choice under these conditions, ridge regression should remain a primary candidate. The residual network establishes an improvement over nominal recursion, rather than a demonstrated need to replace all simpler models.

The direct-versus-residual comparison changes both output decomposition and target normalization. It therefore compares complete training designs and does not uniquely attribute the observed difference to physical priors. Isolating those effects would require additional controls, such as a direct network with matched target scaling. The fixed 25 epoch budget and validation selection also do not establish the best attainable performance of every architecture.

The pressure range, window length and drive period are fixed before testing. Different supply equipment, pipe resistance or stronger contact could change the method ranking. Complete trajectories and predictions are retained so that subsequent studies can locate errors and evaluate whether additional model complexity is worthwhile.

## 5 Conclusion''');q.write_text(s,encoding='utf-8')
body=(p/'论文_zh.md').read_text(encoding='utf-8').split('## 1 引言')[1].split('## 参考文献')[0];body=re.sub(r'\$\$.*?\$\$','',body,flags=re.S);body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','图','表','!')));print('Chinese body',len(re.findall('[\u4e00-\u9fff]',body)))
