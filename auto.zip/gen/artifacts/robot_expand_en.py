from pathlib import Path
q=Path(__file__).with_name('robot_manuscript_en.template');s=q.read_text(encoding='utf-8')
s=s.replace('### 3.2 Temporal encoding and correction','''The nominal parameter is fitted from one step training errors rather than the final test objective. Trajectory contributions use a common mean squared error definition. All trajectories have equal lengths in this experiment. At subsequent forecast steps, the model uses its previous prediction rather than receiving the future true pressure. This prevents teacher forcing from introducing an unrealistic multistep testing advantage.

### 3.2 Temporal encoding and correction''')
s=s.replace('### 3.3 Baselines and evaluation','''The nominal and attention components perform different tasks. The former specifies the basic pressure response to the valve schedule, while the latter estimates discrepancies from the observed history. When several chambers inflate simultaneously, the supply factor depends on total demand, which a single global time constant cannot describe exactly. Deflation and contact changes introduce further differences. Multiple attention heads offer different projections of historical information, but their weights are not interpreted as causal physical influence or as identified actuator parameters.

### 3.3 Baselines and evaluation''')
s=s.replace('### 4.2 Comparison of prediction methods','''Data generation precedes window extraction. Physical parameters, latent pressures and noisy observations are retained for each trajectory. The training, validation and test partitions contain 4960, 992 and 1488 windows, respectively. Despite the larger number of overlapping windows, the test set has only 48 independently sampled physical parameter instances. Repeated network initializations assess optimization variability and do not substitute for multiple devices or environments.

The commands combine a shared cycle, phase offsets and scheduled holds. This represents stages of coordinated actuation rather than a target constructed as a purely sinusoidal pressure waveform. Period, amplitude, initial phase and contact location vary independently between trajectories. The test problem therefore cannot be solved by memorizing one complete trajectory. Low pressure, inflation, deflation and switching windows are all retained, rather than selecting only quasi steady segments.

### 4.2 Comparison of prediction methods''')
s=s.replace('### 4.3 Ablation, horizon and computational cost','''Prediction records retain seed, method, trajectory, forecast origin, horizon, channel, true pressure and predicted pressure. Independent verification reconstructs the trajectory metrics directly from these records instead of calculating backwards from rounded manuscript values. The text, tables and figures consequently share traceable underlying observations. Percentage reduction uses the nominal model error as its denominator; a comparison against persistence is not mislabeled as a comparison against the physical predictor.

### 4.3 Ablation, horizon and computational cost''')
q.write_text(s,encoding='utf-8')
