function robot_experiment(mode)
% Self-contained isothermal three-chamber pressure forecasting experiment.
if nargin==0, mode='pilot'; end
root=fileparts(mfilename('fullpath')); cd(root); rng(42); maxNumCompThreads(4);
diary(fullfile(root,['run_' mode '.log'])); cleanup=onCleanup(@()diary('off'));
fprintf('START %s %s\n',mode,datetime('now')); disp(version); disp(ver);
cfg=struct('dt',0.05,'substep',0.005,'L',32,'H',8,'P0',60,'pa',101.325, ...
    'ntrain',160,'nval',32,'ntest',48,'steps',400,'stride',12,'epochs',25,'seeds',[101 202 303]);
save('params.mat','cfg'); fid=fopen('env.txt','w'); fprintf(fid,'%s\n',version); v=ver; for j=1:numel(v), fprintf(fid,'%s %s\n',v(j).Name,v(j).Version); end; fclose(fid);
if strcmp(mode,'pilot'), cfg.ntrain=8;cfg.nval=2;cfg.ntest=4;cfg.epochs=2;cfg.seeds=101; seed=42; else, seed=20261009; end
rng(seed); n=cfg.ntrain+cfg.nval+cfg.ntest; trajectories=cell(n,1);
for j=1:n, trajectories{j}=makeTrajectory(cfg); end
mins=cellfun(@(a)min(a.p,[],'all'),trajectories); maxs=cellfun(@(a)max(a.p,[],'all'),trajectories);
fprintf('Physical pressure range %.6f %.6f kPa\n',min(mins),max(maxs)); assert(all(mins>=0 & maxs<=cfg.P0+1e-6));
% Nominal globally fitted time constant: no test data are used.
taus=linspace(0.1,0.8,71); costs=zeros(size(taus));
for k=1:numel(taus)
 for j=1:cfg.ntrain
  a=trajectories{j}; q=a.obs(:,1:end-1)+cfg.dt/taus(k)*(a.u(:,1:end-1)-a.obs(:,1:end-1)); costs(k)=costs(k)+mean((q-a.obs(:,2:end)).^2,'all');
 end
end
[~,ix]=min(costs); tau=taus(ix); fprintf('Train-fit nominal tau %.3f s\n',tau);
[X,Y,B,G,F]=windows(trajectories,cfg,tau);
tr=G<=cfg.ntrain; va=G>cfg.ntrain & G<=cfg.ntrain+cfg.nval; te=G>cfg.ntrain+cfg.nval;
fprintf('Windows train=%d val=%d test=%d\n',sum(tr),sum(va),sum(te));
% Ridge uses exactly the network information, vectorized.
Z=double(cell2mat(cellfun(@(x)x(:)',X,'UniformOutput',false))); mu=mean(Z(tr,:)); sd=std(Z(tr,:));sd(sd<1e-5)=1; Z=(Z-mu)./sd; Z=[Z ones(size(Z,1),1)];
lambdas=[0.01 0.1 1 10 100]; err=zeros(size(lambdas)); W=cell(size(lambdas));
for k=1:numel(lambdas), W{k}=(Z(tr,:)'*Z(tr,:)+lambdas(k)*eye(size(Z,2)))\(Z(tr,:)'*double(Y(tr,:)));err(k)=mean((Z(va,:)*W{k}-double(Y(va,:))).^2,'all');end
[~,ir]=min(err); ridgeW=W{ir}; ridgePred=Z(te,:)*ridgeW;
names={'Hold','Nominal','Ridge','LSTM','TransformerDirect','TransformerResidual'};
pred=zeros(sum(te),24,numel(names),numel(cfg.seeds),'single'); holdPred=zeros(sum(te),24); xx=X(te);
for k=1:numel(xx), holdPred(k,:)=repmat(xx{k}(1:3,end)',1,cfg.H); end
for r=1:numel(cfg.seeds),pred(:,:,1,r)=holdPred;pred(:,:,2,r)=B(te,:);pred(:,:,3,r)=ridgePred;end
trainSeconds=zeros(3,numel(cfg.seeds));
for r=1:numel(cfg.seeds)
 for typ=1:3
  rng(cfg.seeds(r)); residual=typ==3; outputScale=1; if residual, outputScale=0.05; end; target=(Y-residual*B)/outputScale;
  if typ==1
   layers=[sequenceInputLayer(31,Normalization='none');lstmLayer(32,OutputMode='last');fullyConnectedLayer(24);regressionLayer];
  else
   layers=transformerLayers;
  end
  opt=trainingOptions('adam',MaxEpochs=cfg.epochs,MiniBatchSize=128,InitialLearnRate=0.002,Shuffle='every-epoch', ...
    ValidationData={X(va),target(va,:)},ValidationFrequency=40,OutputNetwork='best-validation-loss',ExecutionEnvironment='cpu',Verbose=true,VerboseFrequency=100,Plots='none');
  fprintf('TRAIN type=%d seed=%d\n',typ,cfg.seeds(r));
  checkpoint=sprintf('model_%s_%d.mat',names{typ+3},cfg.seeds(r));
  if strcmp(mode,'resume') && isfile(checkpoint)
   stored=load(checkpoint,'net');net=stored.net;times=readmatrix('training_times.csv');trainSeconds(typ,r)=times(typ,r);
  else
   tic;net=trainNetwork(X(tr),target(tr,:),layers,opt);trainSeconds(typ,r)=toc;
  end
  pred(:,:,typ+3,r)=outputScale*predict(net,X(te),MiniBatchSize=128)+residual*B(te,:);
  save(sprintf('model_%s_%d.mat',names{typ+3},cfg.seeds(r)),'net','cfg','tau');
 end
end
target=Y(te,:);group=G(te); forecastIndex=F(te); pred=pred*cfg.P0;target=target*cfg.P0;
rows=[];
for r=1:numel(cfg.seeds),for m=1:numel(names),for g=unique(group)'
 d=double(pred(group==g,:,m,r))-target(group==g,:); rows(end+1,:)=[cfg.seeds(r),m,g,sqrt(mean(d.^2,'all')),mean(abs(d),'all')];
end,end,end
metrics=array2table(rows,VariableNames={'seed','method','trajectory','RMSE_kPa','MAE_kPa'});writetable(metrics,'metrics.csv');
% All prediction-level values preserved for independent recomputation.
rows=zeros(numel(cfg.seeds)*numel(names)*numel(target),8);rr=0;for r=1:numel(cfg.seeds),for m=1:numel(names)
 for k=1:size(target,1),for h=1:cfg.H,for c=1:3,col=(h-1)*3+c;rr=rr+1;rows(rr,:)=[cfg.seeds(r),m,group(k),forecastIndex(k),h,c,target(k,col),pred(k,col,m,r)];end,end,end
end,end
writetable(array2table(rows,VariableNames={'seed','method','trajectory','origin','horizon','channel','truth_kPa','prediction_kPa'}),'raw_results.csv');
save('raw_results.mat','trajectories','cfg','seed','tau','pred','target','group','forecastIndex','metrics','names','trainSeconds','ridgeW','mu','sd','-v7.3');
summary=struct('mode',mode,'methodNames',{names},'tau',tau,'trainSeconds',trainSeconds,'rmse',zeros(1,6),'mae',zeros(1,6));
for m=1:6,summary.rmse(m)=mean(metrics.RMSE_kPa(metrics.method==m));summary.mae(m)=mean(metrics.MAE_kPa(metrics.method==m));end
fid=fopen('summary.json','w');fprintf(fid,'%s',jsonencode(summary,PrettyPrint=true));fclose(fid);disp(summary);
if ~exist('图','dir'),mkdir('图');end
a=trajectories{cfg.ntrain+cfg.nval+1}; t=(0:cfg.steps-1)*cfg.dt;
f=figure(Visible='off',Position=[100 100 900 540]);tiledlayout(2,1);nexttile;plot(t,a.u');ylabel('Command (kPa)');legend('Front','Body','Rear',Location='eastoutside');nexttile;plot(t,a.p');xlabel('Time (s)');ylabel('Pressure (kPa)');legend('Front','Body','Rear',Location='eastoutside');savefig(f,fullfile('图','figure1.fig'));exportgraphics(f,fullfile('图','figure1.png'),Resolution=220);close(f);
f=figure(Visible='off',Position=[100 100 1050 450]);av=zeros(1,6);st=av;for m=1:6,vals=metrics.RMSE_kPa(metrics.method==m);av(m)=mean(vals);st(m)=std(vals);end;bar(av);hold on;errorbar(1:6,av,st,'.k');xticks(1:6);xticklabels(names);xtickangle(18);ylabel('Trajectory RMSE (kPa), mean +/- SD');grid on;savefig(f,fullfile('图','figure2.fig'));exportgraphics(f,fullfile('图','figure2.png'),Resolution=220);close(f);
f=figure(Visible='off',Position=[100 100 950 440]);hold on;for m=1:6,er=zeros(1,cfg.H);for h=1:cfg.H,d=double(pred(:,(h-1)*3+(1:3),m,:))-target(:,(h-1)*3+(1:3));er(h)=sqrt(mean(d.^2,'all'));end;plot((1:cfg.H)*cfg.dt,er,'-o',DisplayName=names{m});end;xlabel('Forecast horizon (s)');ylabel('Pooled RMSE (kPa)');legend(Location='eastoutside');grid on;savefig(f,fullfile('图','figure3.fig'));exportgraphics(f,fullfile('图','figure3.png'),Resolution=220);close(f);
fprintf('END %s\n',datetime('now'));
end
function a=makeTrajectory(c)
T=c.steps;u=zeros(3,T);baseTau=0.15+0.25*rand(3,1);compliance=0.1+0.3*rand(3,1);beta=0.1+0.4*rand;leak=0.005+0.02*rand(3,1);
period=1.3+1.8*rand; phase=rand*2*pi; amp=30+30*rand(3,1);t=(0:T-1)*c.dt;
for k=1:3,u(k,:)=amp(k)*(0.5+0.5*tanh(3*sin(2*pi*t/period+phase+(k-1)*2*pi/3)));end
% Independent planned hold and amplitude changes; all methods see same schedule.
for k=1:3,for j=80:80:T,u(k,j:min(T,j+25))=u(k,max(1,j-1));end,end
p=zeros(3,T);p(:,1)=u(:,1).*rand(3,1);contactAt=randi([130 260]);contactScale=0.45+0.4*rand; vbase=ones(3,1);
for j=1:T-1
 q=p(:,j);comp=compliance;if j>=contactAt,comp(2)=comp(2)*contactScale;end
 if j==contactAt,vbase(2)=1+(compliance(2)-comp(2))*q(2)/c.P0;end
 for s=1:round(c.dt/c.substep)
  den=vbase+comp.*(2*q+c.pa)/c.P0; flow=(u(:,j)-q)./baseTau; loadFactor=1/(1+beta*sum(max(u(:,j)-q,0))/c.P0);flow(flow>0)=flow(flow>0)*loadFactor;
  q=q+c.substep*(flow-leak.*q)./den;
 end;p(:,j+1)=q;
end
a=struct('p',p,'obs',p+0.3*randn(size(p)),'u',u,'tau',baseTau,'compliance',compliance,'beta',beta,'leak',leak,'contactAt',contactAt,'contactScale',contactScale);
end
function [X,Y,B,G,F]=windows(a,c,tau)
X={};Y=[];B=[];G=[];F=[];
for g=1:numel(a),v=a{g};for j=c.L:c.stride:c.steps-c.H
 future=v.u(:,j:j+c.H-1); x=[v.obs(:,j-c.L+1:j)/c.P0;v.u(:,j-c.L+1:j)/c.P0;linspace(-1,0,c.L);repmat(future(:)/c.P0,1,c.L)];
 q=v.obs(:,j); b=zeros(3,c.H);for h=1:c.H,q=q+c.dt/tau*(future(:,h)-q);b(:,h)=q;end
 X{end+1,1}=single(x);truth=v.p(:,j+1:j+c.H);Y(end+1,:)=truth(:)'/c.P0;B(end+1,:)=b(:)'/c.P0;G(end+1,1)=g;F(end+1,1)=j;
end,end
Y=single(Y);B=single(B);
end
function l=transformerLayers
l=layerGraph([sequenceInputLayer(31,Normalization='none',Name='input');fullyConnectedLayer(32,Name='embed'); ...
 selfAttentionLayer(4,32,Name='attn');additionLayer(2,Name='add1');layerNormalizationLayer(Name='norm1'); ...
 fullyConnectedLayer(64,Name='ff1');reluLayer(Name='relu');fullyConnectedLayer(32,Name='ff2'); ...
 additionLayer(2,Name='add2');layerNormalizationLayer(Name='norm2');indexing1dLayer('last',Name='last');fullyConnectedLayer(24,Name='out');regressionLayer(Name='loss')]);
l=connectLayers(l,'embed','add1/in2');l=connectLayers(l,'norm1','add2/in2');
end
