function robot_figures
root=fileparts(mfilename('fullpath'));cd(root);s=load('raw_results.mat');c=s.cfg;
set(groot,'defaultAxesFontSize',16,'defaultTextFontSize',16,'defaultAxesFontName','Times New Roman');
names={'Hold','Nominal','Ridge','LSTM','Direct','Residual'}; styles={'--','-.',':','-','--','-'};
a=s.trajectories{c.ntrain+c.nval+1};t=(0:c.steps-1)*c.dt;
f=figure(Visible='off',Position=[100 100 630 560]);tiledlayout(2,1,TileSpacing='compact');
nexttile;plot(t,a.u','LineWidth',1.2);ylabel('Command (kPa)');legend('Front','Body','Rear',Location='northoutside',Orientation='horizontal',FontSize=13);grid on;
nexttile;plot(t,a.p','LineWidth',1.2);xlabel('Time (s)');ylabel('Pressure (kPa)');grid on;out(f,1);
f=figure(Visible='off',Position=[100 100 630 450]);av=zeros(1,6);st=av;for m=1:6,v=s.metrics.RMSE_kPa(s.metrics.method==m);av(m)=mean(v);st(m)=std(v);end
bar(av);hold on;errorbar(1:6,av,st,'.k','LineWidth',1.2);xticks(1:6);xticklabels(names);xtickangle(35);ylabel('Trajectory RMSE (kPa)');grid on;out(f,2);
f=figure(Visible='off',Position=[100 100 630 490]);hold on;
for m=1:6,er=zeros(1,c.H);for h=1:c.H,d=double(s.pred(:,(h-1)*3+(1:3),m,:))-s.target(:,(h-1)*3+(1:3));er(h)=sqrt(mean(d.^2,'all'));end;plot((1:c.H)*c.dt,er,styles{m},LineWidth=1.8,DisplayName=names{m});end
xlabel('Forecast horizon (s)');ylabel('Pooled RMSE (kPa)');legend(Location='northoutside',NumColumns=3,FontSize=13);grid on;out(f,3);
end
function out(f,i)
savefig(f,fullfile('图',sprintf('figure%d.fig',i)));exportgraphics(f,fullfile('图',sprintf('figure%d.png',i)),Resolution=250);close(f);
end
