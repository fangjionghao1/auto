function robot_numeric_check
root=fileparts(mfilename('fullpath'));cd(root);s=load('raw_results.mat','trajectories','cfg');c=s.cfg;errors=[];jumps=[];
for idx=c.ntrain+c.nval+1:numel(s.trajectories)
 a=s.trajectories{idx};dt=c.substep/2;p=a.p(:,1);out=zeros(size(a.p));out(:,1)=p;vb=ones(3,1);
 for k=1:c.steps-1
  comp=a.compliance;if k>=a.contactAt,comp(2)=comp(2)*a.contactScale;end
  if k==a.contactAt
   old=1+a.compliance(2)*p(2)/c.P0;vb(2)=1+(a.compliance(2)-comp(2))*p(2)/c.P0;new=vb(2)+comp(2)*p(2)/c.P0;jumps(end+1)=abs(old-new);
  end
  for it=1:round(c.dt/dt)
   flow=(a.u(:,k)-p)./a.tau;factor=1/(1+a.beta*sum(max(a.u(:,k)-p,0))/c.P0);flow(flow>0)=flow(flow>0)*factor;
   p=p+dt*(flow-a.leak.*p)./(vb+comp.*(2*p+c.pa)/c.P0);
  end
  out(:,k+1)=p;
 end
 errors(end+1,:)=[idx,max(abs(out-a.p),[],'all'),sqrt(mean((out-a.p).^2,'all'))];
end
writematrix(errors,'integration_check.csv');f=fopen('integration_check.json','w');fprintf(f,'%s',jsonencode(struct('test_trajectories',size(errors,1),'max_abs_kPa',max(errors(:,2)),'mean_trajectory_RMSE_kPa',mean(errors(:,3)),'max_normalized_volume_jump',max(jumps)),PrettyPrint=true));fclose(f);
for i=1:3,f=openfig(fullfile('图',sprintf('figure%d.fig',i)),'invisible');assert(~isempty(findobj(f,'Type','axes')));close(f);end
disp('Integration and editable FIG checks completed');
end
