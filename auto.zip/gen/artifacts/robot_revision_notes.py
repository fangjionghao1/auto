from pathlib import Path
import json
root=Path(__file__).parent
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
(p/'重设计记录.md').write_text('''# R0至R1模型修正\n\nR0将容积写为V/V0=1+c p/P0，同时在接触时突变c；这会使同一压力对应的容积不连续，原推导缺少瞬时容积变化项。该问题不依赖预测结果，属于质量守恒边界错误。R0结果只归档，不作为终稿数据。\n\nR1在接触时以p*为当前压力，将V/V0改为a+c_new p/P0，其中a=1+(c_old-c_new)p*/P0。这样切换前后容积和压力都连续，后续有效电容为a+c_new(2p+pa)/P0，且a大于等于1。气体质量在接触切换时保持连续。测试输入不透露c或a。\n\n保持其余分布、指标、基线、种子及训练预算不变；R1数据种子20261009，避免把已运行的R0测试当新保留测试。岭回归的矩阵和目标都转double，避免混合精度求解警告。重新执行全部实验与V2复算，不以改文掩盖模型变化。\n\nR0在批次根运行，输出按清单归档至仿真/R0；R1以仿真/R1为真实工作目录启动，后续一键入口从当前项目解析路径。\n''',encoding='utf-8')
with (p/'实验设计.md').open('a',encoding='utf-8') as f:f.write('\n## R1冻结补充\n容积连续性修正详见重设计记录；最终数据种子20261009，接触后电容分母1替换为a，残差训练目标以3 kPa标准化，岭回归全程double。主结果使用R1。\n')
for lang in ['zh','en']:
    q=root/f'robot_manuscript_{lang}.template';s=q.read_text(encoding='utf-8');s=s.replace('1+c_i(2p_i+p_a)/P_0','a_i+c_i(2p_i+p_a)/P_0')
    if lang=='zh':
        s=s.replace('其中$\\u007e p$表示带噪观测','其中$\\tilde p$表示带噪观测')
        s=s.replace('这里$\\tau_i$为名义时间常数','接触前$a_i=1$。接触切换时，以当前压力$p_i^*$设$a_i=1+(c_{i,旧}-c_{i,新})p_i^*/P_0$，保证$V_i/V_{0,i}=a_i+c_i p_i/P_0$连续，随后按新顺应性积分。这里$\\tau_i$为名义时间常数')
        s=s.replace('声称已满足嵌入式实时部署要求。','声称已满足嵌入式实时部署要求。')
    else:
        s=s.replace('The time constant $\\tau_i$ is in seconds','Before contact, $a_i=1$. At the contact switch, $a_i=1+(c_{i,old}-c_{i,new})p_i^*/P_0$ is set using the current pressure, so that normalized volume $a_i+c_i p_i/P_0$ remains continuous. Pressure and gas mass therefore remain continuous at the switch. The time constant $\\tau_i$ is in seconds')
    q.write_text(s,encoding='utf-8')
print('R1 recorded')
