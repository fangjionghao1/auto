from pathlib import Path
import json, urllib.request, concurrent.futures, datetime
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
dois=['10.1007/s11465-020-0605-3','10.1002/aisy.202300828','10.3389/frobt.2021.557830','10.3389/frobt.2023.1056118','10.3390/act14070321','10.1109/IROS55552.2023.10342379','10.1016/j.ijforecast.2021.03.012','10.1609/aaai.v37i9.26317','10.1002/aisy.202500696','10.1016/j.birob.2024.100192']
def fetch(d):
    url='https://api.crossref.org/works/'+d
    try:
        data=json.loads(urllib.request.urlopen(url,timeout=45).read())['message']
        return dict(doi=d,url=url,checked_at=datetime.datetime.now().isoformat(),metadata=data)
    except Exception as e:return dict(doi=d,error=str(e))
results=list(concurrent.futures.ThreadPoolExecutor(max_workers=5).map(fetch,dois))
(p/'文献元数据.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
for i,r in enumerate(results,1):
    m=r.get('metadata',{});print(i,r['doi'],m.get('title'),m.get('published'),m.get('volume'),m.get('page'),r.get('error'))
note='''# 先导核验与实现修正\n\n先导已在真实MATLAB R2025b运行，种子42，8/2/4条轨迹。压力范围0.025430—58.764670 kPa满足边界；名义时间常数0.470 s。Python数量级复核积分步长/最小有效时间常数=0.028517，正气动电容且边界流向向内。\n\n两轮训练仅用于执行链探测，不能用于神经网络优劣结论：保持/名义/岭回归/LSTM/直接Transformer/残差Transformer轨迹RMSE依次约7.3205/1.5240/1.7696/25.7475/54.0672/49.1377 kPa。网络尚未收敛。\n\n保留pilot全部结果；主实验前将岭回归计算转double以消除病态单精度警告，将残差训练目标按3 kPa尺度归一化（预测时反变换），这是优化尺度修正，不改变物理模型、评价指标或标签。主实验使用25轮及独立种子20261008，三个训练种子均保留。先导运行未支持放行，主实验后才判断实验贡献。\n'''
(p/'先导核验.md').write_text(note,encoding='utf-8')
