from pathlib import Path
import sys, subprocess
from copy import deepcopy
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
p=Path(sys.argv[1]); doc=Document(p)
first=doc.paragraphs[0]._p
if not first.xpath('./w:pPr/w:sectPr'):
 title_section=deepcopy(doc.sections[0]._sectPr)
 cols=title_section.find(qn('w:cols'));cols.set(qn('w:num'),'1')
 typ=title_section.find(qn('w:type'))
 if typ is None:typ=OxmlElement('w:type');title_section.insert(0,typ)
 typ.set(qn('w:val'),'continuous')
 first.get_or_add_pPr().append(title_section)
for style in doc.styles:
 if style.type==1:
  style.font.color.rgb=RGBColor(0,0,0)
for para in doc.paragraphs:
 if para.text.startswith(('Figure ', 'Table ')) and len(para.text)>180:
  para.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
  for run in para.runs:run.font.size=Pt(10.5)
 if para.text.strip() in ['参考文献','References']:
  para.paragraph_format.page_break_before=True
 if para.text.startswith(('图1 ','图2 ','图3 ','Figure 1 ','Figure 2 ','Figure 3 ')):
  para.paragraph_format.keep_with_next=False
  para.paragraph_format.space_before=Pt(2)
 if para._p.xpath('.//w:drawing'):
  para.paragraph_format.keep_with_next=True
for table in doc.tables:
 for ri,row in enumerate(table.rows):
  for cell in row.cells:
   pr=cell._tc.get_or_add_tcPr()
   for old in list(pr.findall(qn('w:tcBorders'))):pr.remove(old)
   borders=OxmlElement('w:tcBorders')
   for side in ['top','bottom','left','right']:
    edge=OxmlElement('w:'+side)
    draw=(ri==0 and side in ['top','bottom']) or (ri==len(table.rows)-1 and side=='bottom')
    edge.set(qn('w:val'),'single' if draw else 'nil');edge.set(qn('w:sz'),'6');borders.append(edge)
   pr.append(borders)
 for row in table.rows[:-1]:
  for cell in row.cells:
   for para in cell.paragraphs:
    para.paragraph_format.keep_with_next=True
for i,table in enumerate(doc.tables,1):
 for para in list(doc.paragraphs):
  if para.text.startswith((f'Table {i} ',f'表{i} ')) and len(para.text)<120:
   para._p.getparent().remove(para._p)
   table._tbl.addprevious(para._p)
   para.paragraph_format.keep_with_next=True
   break
for section in doc.sections:
 typ=section._sectPr.find(qn('w:type'))
 if typ is None:typ=OxmlElement('w:type');section._sectPr.insert(0,typ)
 typ.set(qn('w:val'),'continuous')
 para=section.footer.paragraphs[0];para.alignment=WD_ALIGN_PARAGRAPH.CENTER
 if not para._p.xpath('.//w:fldSimple'):
  fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');para._p.append(fld)
doc.save(p)
pdf=p.with_suffix('.pdf')
command=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(Path(__file__).with_name('export_word.ps1')),'-DocPath',str(p),'-PdfPath',str(pdf)]
proc=subprocess.run(command,capture_output=True,text=True);print(proc.stdout,proc.stderr);assert proc.returncode==0 and pdf.exists()
out=p.parent/'排版核验'/p.stem;out.mkdir(parents=True,exist_ok=True)
subprocess.run(['pdftoppm','-png','-r','100',str(pdf),str(out/'page')],check=True)
print(pdf); print(subprocess.check_output(['pdfinfo',str(pdf)],text=True,errors='replace'))
