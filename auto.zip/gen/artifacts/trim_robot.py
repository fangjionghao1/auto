from pathlib import Path
import json,re
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
for lang,starts in [('zh',['名义参数的选择采用一步误差','结果文件按训练种子','此外，本实验的主要压力范围']),('en',['The nominal parameter is fitted','Prediction records retain seed','The pressure range, window length'])]:
 q=p/f'论文_{lang}.md';text=q.read_text(encoding='utf-8');paragraphs=text.split('\n\n');text='\n\n'.join(t for t in paragraphs if not any(t.startswith(x) for x in starts));q.write_text(text,encoding='utf-8')
body=(p/'论文_zh.md').read_text(encoding='utf-8').split('## 1 引言')[1].split('## 参考文献')[0]
body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','!')) and not re.match(r'^[图表]\s*\d+\s',x));print('body Chinese chars',len(re.findall('[\u4e00-\u9fff]',body)))
