from pathlib import Path
import json, numpy as np, pandas as pd, hashlib
root=Path(__file__).parent
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][0]['path'])
sim=p/'仿真'/'R1'
d=pd.read_csv(sim/'raw_results.csv')
d['sq']=(d.truth_kPa-d.prediction_kPa)**2;d['abs']=(d.truth_kPa-d.prediction_kPa).abs()
g=d.groupby(['seed','method','trajectory']).agg(mse=('sq','mean'),mae=('abs','mean'));g['rmse']=np.sqrt(g.mse)
reported=pd.read_csv(sim/'metrics.csv').set_index(['seed','method','trajectory'])
delta=float(np.max(abs(g.rmse-reported.RMSE_kPa)))
assert delta<1e-5
assert len(d)==3*6*48*31*24
wide=g.rmse.unstack('method').groupby('trajectory').mean()
diff=wide[2]-wide[6]
rng=np.random.default_rng(9876);boot=np.mean(rng.choice(diff.to_numpy(),(10000,len(diff)),replace=True),axis=1)
stats=dict(max_metric_delta=delta,prediction_rows=len(d),trajectories=len(wide),rmse=g.groupby('method').rmse.mean().tolist(),mae=g.groupby('method').mae.mean().tolist(),paired_mean_gain_kPa=float(diff.mean()),paired_bootstrap_95CI=np.quantile(boot,[.025,.975]).tolist(),better_trajectories=int((diff>0).sum()),horizon_rmse=d.groupby(['method','horizon']).sq.mean().pow(.5).unstack('horizon').to_dict('index'),raw_sha256=hashlib.sha256((sim/'raw_results.csv').read_bytes()).hexdigest())
(p/'独立复算.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
g.to_csv(p/'独立复算.csv');print(json.dumps(stats,ensure_ascii=False,indent=2))
