from pathlib import Path
import json, numpy as np, pandas as pd, urllib.request
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][1]['path'])
f=p/'文献元数据.json'; refs=json.loads(f.read_text(encoding='utf-8'))
for r in refs:
 if 'error' in r:
  try:r['metadata']=json.loads(urllib.request.urlopen('https://api.crossref.org/works/'+r['doi'],timeout=45).read())['message'];r.pop('error')
  except Exception:pass
f.write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')
sim=p/'仿真'/'main'
if not (sim/'raw_results.csv').exists():print('Metadata retried; results pending');raise SystemExit
d=pd.read_csv(sim/'raw_results.csv'); rows=[]
def head(a):
 pk=int(np.argmax(a));mx=a[pk];below=np.flatnonzero(a[:pk+1]<=.5*mx)
 if not len(below):return 0.
 j=int(below[-1]);return (j+(.5*mx-a[j])/(a[j+1]-a[j]))*.1 if j<pk else pk*.1
for (ev,seed,method),q in d.groupby(['event','seed','method'],sort=True):
 e=q.prediction_kV.to_numpy()-q.truth_kV.to_numpy()
 rows.append([ev,seed,method,np.sqrt(np.mean(e**2)),np.mean(abs(e)),abs(head(q.prediction_kV.to_numpy())-head(q.truth_kV.to_numpy())),q.snr_dB.iloc[0]])
r=pd.DataFrame(rows,columns=['event','seed','method','rmse','mae','timing','snr']);r.to_csv(p/'独立复算.csv',index=False)
s=r.groupby('method')[['rmse','mae','timing']].mean();orig=pd.read_csv(sim/'metrics.csv').iloc[:,1:];delta=float(np.max(abs(s.to_numpy()-orig.to_numpy())))
pair=r.groupby(['event','method']).rmse.mean().unstack();gain=(pair[3]-pair[5]).to_numpy();rng=np.random.default_rng(812);ci=np.quantile(np.mean(rng.choice(gain,(5000,len(gain))),axis=1),[.025,.975])
out={'rows':len(d),'events':r.event.nunique(),'max_difference':delta,'metrics':s.to_dict('index'),'paired_gain_vs_tikhonov_kV':float(gain.mean()),'bootstrap95':ci.tolist(),'events_improved':int(sum(gain>0)),'snr_metrics':r.groupby(['snr','method'])[['rmse','timing']].mean().reset_index().to_dict('records'),'seed_metrics':r.groupby(['seed','method'])[['rmse','timing']].mean().reset_index().to_dict('records')}
(p/'独立复算.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2))
