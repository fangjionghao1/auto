function wave_experiment(mode)
if nargin<1,mode='main';end
if ~isfolder(fullfile(pwd,mode)),mkdir(fullfile(pwd,mode));end
cd(mode); diary('run.log'); fprintf('Start %s\n',string(datetime));
p=struct('dt',.1,'N',192,'seed',20261010,'ntr',1800,'nv',300,'nt',450,'epochs',20,'seeds',[101 202 303]);
if strcmp(mode,'pilot'),p.ntr=120;p.nv=30;p.nt=45;p.epochs=2;p.seeds=42;p.seed=42;end
save('params.mat','p'); fid=fopen('env.txt','w');fprintf(fid,'%s\n%s',version,evalc('ver'));fclose(fid);
rng(p.seed); n=p.ntr+p.nv+p.nt; t=(0:p.N-1)*p.dt;
clean=zeros(n,p.N); obs=clean; tau=zeros(n,1); snrdb=tau; arrival=tau;
for i=1:n
 a=.6+.6*rand;arrival(i)=3+4*rand;tr=.15+.45*rand;td=4+5*rand;delay=3+3*rand;rr=-.35+.7*rand;tau(i)=.15+.4*rand;
 s=max(t-arrival(i),0);sr=max(t-arrival(i)-delay,0);x=a*(1-exp(-s/tr)).*exp(-s/td)+rr*a*(1-exp(-sr/tr)).*exp(-sr/td);
 pole=exp(-p.dt/tau(i));y=filter(1-pole,[1 -pole],x);snrdb(i)=20+10*mod(i-1,3);
 noise=.7*randn(1,p.N)+.3*filter(1,[1 -.6],randn(1,p.N));noise=noise/sqrt(mean(noise.^2));
 clean(i,:)=x;obs(i,:)=y+noise*sqrt(mean(y.^2))*10^(-snrdb(i)/20);
end
tridx=1:p.ntr;vidx=p.ntr+(1:p.nv);teidx=p.ntr+p.nv+(1:p.nt);
lambdaGrid=logspace(-5,0,16);val=zeros(size(lambdaGrid));
for j=1:numel(lambdaGrid),v=invreg(obs(vidx,:),tau(vidx),p.dt,lambdaGrid(j));val(j)=mean((v-clean(vidx,:)).^2,'all');end
[~,ix]=min(val);lambda=lambdaGrid(ix);reg=invreg(obs,tau,p.dt,lambda); exact=zeros(size(obs));
for i=1:n,a=exp(-p.dt/tau(i));exact(i,:)=(obs(i,:)-a*[0 obs(i,1:end-1)])/(1-a);end
save('raw_data.mat','clean','obs','reg','exact','tau','snrdb','arrival','tridx','vidx','teidx','p','lambda','lambdaGrid','val','-v7.3');
names={'Observed','ExactInverse','Tikhonov','DirectCNN','ResidualCNN'}; pred=zeros(p.nt,p.N,5,numel(p.seeds),'single');
X=cell(n,1);Y=cell(n,1);R=cell(n,1);
for i=1:n,X{i}=single([obs(i,:);reg(i,:);ones(1,p.N)*tau(i)]);Y{i}=single(clean(i,:));R{i}=single((clean(i,:)-reg(i,:))/.1);end
for k=1:numel(p.seeds)
 pred(:,:,1,k)=obs(teidx,:);pred(:,:,2,k)=exact(teidx,:);pred(:,:,3,k)=reg(teidx,:);
 for typ=1:2
  rng(p.seeds(k));layers=[sequenceInputLayer(3,Normalization='none');convolution1dLayer(9,24,Padding='same');reluLayer;convolution1dLayer(9,24,Padding='same',DilationFactor=2);reluLayer;convolution1dLayer(9,24,Padding='same',DilationFactor=4);reluLayer;convolution1dLayer(1,1);regressionLayer];
  target=Y;if typ==2,target=R;end
  opts=trainingOptions('adam',MaxEpochs=p.epochs,MiniBatchSize=64,InitialLearnRate=.001,Shuffle='every-epoch',Verbose=false,Plots='none',ExecutionEnvironment='cpu');
  fn=sprintf('model_%d_%d.mat',typ,p.seeds(k));
  if exist(fn,'file'),load(fn,'net');else,tt=tic;net=trainNetwork(X(tridx),target(tridx),layers,opts);elapsed=toc(tt);save(fn,'net','elapsed');end
  q=predict(net,X(teidx),MiniBatchSize=64);for i=1:p.nt,z=double(q{i});if typ==2,z=reg(teidx(i),:)+.1*z;end;pred(i,:,typ+3,k)=z;end
  fprintf('Finished model %d seed %d at %s\n',typ,p.seeds(k),string(datetime));
 end
end
truth=clean(teidx,:);timetrue=head(truth,p.dt);metrics=zeros(p.nt,5,numel(p.seeds),3);
for k=1:numel(p.seeds),for m=1:5,d=double(pred(:,:,m,k))-truth;metrics(:,m,k,1)=sqrt(mean(d.^2,2));metrics(:,m,k,2)=mean(abs(d),2);metrics(:,m,k,3)=abs(head(double(pred(:,:,m,k)),p.dt)-timetrue);end,end
save('raw_results.mat','pred','truth','metrics','names','p','tau','snrdb','teidx','timetrue','lambda','-v7.3');
nr=p.nt*p.N*5*numel(p.seeds);A=zeros(nr,7);pos=0;
for k=1:numel(p.seeds),for m=1:5,for i=1:p.nt,ii=pos+(1:p.N);A(ii,:)=[ones(p.N,1)*i ones(p.N,1)*p.seeds(k) ones(p.N,1)*m t' truth(i,:)' double(squeeze(pred(i,:,m,k)))' ones(p.N,1)*snrdb(teidx(i))];pos=pos+p.N;end,end,end
writetable(array2table(A,'VariableNames',{'event','seed','method','time_us','truth_kV','prediction_kV','snr_dB'}),'raw_results.csv');
M=squeeze(mean(mean(metrics,1),3));writetable(table(string(names)',M(:,1),M(:,2),M(:,3),'VariableNames',{'method','RMSE_kV','MAE_kV','timing_MAE_us'}),'metrics.csv');disp(M);
if ~exist('图','dir'),mkdir('图');end
set(groot,'defaultAxesFontSize',11,'defaultLineLineWidth',1.4);
f=figure('Visible','off','Position',[50 50 900 360]);plot(t,truth(1,:),'k',t,squeeze(pred(1,:,1,1)),'--',t,squeeze(pred(1,:,3,1)),':',t,squeeze(pred(1,:,5,1)),'-.');xlabel('Time (microseconds)');ylabel('Voltage (kV)');legend('Clean input','Observed','Tikhonov','Residual CNN','Location','eastoutside');grid on;savefig(f,'图/fig1.fig');exportgraphics(f,'图/fig1.png',Resolution=200);close(f);
f=figure('Visible','off','Position',[50 50 900 400]);mu=M(:,1);sd=std(squeeze(mean(metrics(:,:,:,1),3)),0,1);bar(mu);hold on;errorbar(1:5,mu,sd,'k.');xticks(1:5);xticklabels(names);xtickangle(20);ylabel('Event RMSE (kV), mean +/- SD');grid on;savefig(f,'图/fig2.fig');exportgraphics(f,'图/fig2.png',Resolution=200);close(f);
f=figure('Visible','off','Position',[50 50 900 360]);hold on;styles={'-o','--s',':d','-.^','-v'};for m=1:5,q=zeros(3,1);for j=1:3,q(j)=mean(metrics(snrdb(teidx)==10+j*10,m,:,3),'all');end;plot([20 30 40],q,styles{m});end;xlabel('SNR (dB)');ylabel('Wavehead timing MAE (microseconds)');legend(names,'Location','eastoutside');grid on;savefig(f,'图/fig3.fig');exportgraphics(f,'图/fig3.png',Resolution=200);close(f);
fid=fopen('summary.json','w');fprintf(fid,'%s',jsonencode(struct('lambda',lambda,'metrics',M,'names',{names},'finished',char(datetime))));fclose(fid);diary off;
end
function z=invreg(y,tau,dt,lambda)
N=size(y,2);L=2*N;z=zeros(size(y));w=2*pi*(0:L-1)/L;
for i=1:size(y,1),a=exp(-dt/tau(i));H=(1-a)./(1-a*exp(-1i*w));q=real(ifft(fft(y(i,:),L).*conj(H)./(abs(H).^2+lambda)));z(i,:)=q(1:N);end
end
function tt=head(y,dt)
tt=zeros(size(y,1),1);
for i=1:size(y,1),[mx,pk]=max(y(i,:));ix=find(y(i,1:pk)<=.5*mx,1,'last');if isempty(ix),tt(i)=0;elseif ix>=pk,tt(i)=(pk-1)*dt;else,tt(i)=((ix-1)+(.5*mx-y(i,ix))/(y(i,ix+1)-y(i,ix)))*dt;end,end
end


