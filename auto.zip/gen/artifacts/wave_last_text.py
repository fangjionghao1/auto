from paper_helpers import project
import re
p=project(1)
for lang in ['zh','en']:
 q=p/f'论文_{lang}.md';s=q.read_text(encoding='utf-8').replace(r'{\rm kV}',r'\mathrm{kV}')
 if lang=='zh':
  s=s.replace('正时间常数保证极点位于单位圆内。','正时间常数保证极点位于单位圆内。该递推可由常系数微分方程在一个采样区间内积分得到，因此无需再选择显式积分子步，也不存在通过调整积分步长改善某个学习模型结果的问题。噪声叠加在测量输出端，反演目标不包含这一噪声；训练时可以获得干净标签，测试时所有方法只能访问观测及已知测量参数。')
  s=s.replace('本文因此保留直接学习这一更简单的输出形式，不宣称残差连接具有普遍优势。','本文因此保留直接学习这一更简单的输出形式，不宣称残差连接具有普遍优势。两种模型参数数量相同，这里的“更简单”仅指输出无需再加正则逆，不代表计算量或存储量已被证明更小。由于两者输入仍包含正则逆，均需要执行该预处理。若要判断能否移除解析分支，还需另设只输入观测与时间常数的独立消融；本文没有用当前比较代替这一未开展试验。')
 else:
  s=s.replace('A positive time constant places the discrete pole inside the unit circle.','A positive time constant places the discrete pole inside the unit circle. The recursion follows interval-wise integration of the constant-coefficient differential equation, so no explicit integration substep is tuned. Noise is added after the measurement chain; only training targets contain the clean waveform.')
  s=s.replace('The results therefore retain direct prediction as the better output formulation and do not support a universal residual-connection advantage.','The results therefore retain direct prediction as the better output formulation and do not support a universal residual-connection advantage. Simpler output does not imply demonstrated computational savings: both inputs still include the regularized inverse. Removing that preprocessing branch would require a separate ablation that was not performed.')
 q.write_text(s,encoding='utf-8')
 body=s.split('## 1 ',1)[1].split('## 参考文献' if lang=='zh' else '## References')[0];body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','![')) and not re.match(r'^(?:图|表)\d+\s|^(?:Figure|Table) \d+ ',x));print(lang,len(re.findall('[\u4e00-\u9fff]',body)))
