function wave_numeric
rng(91);dt=.1;t=(0:191)*dt;x=(1-exp(-max(t-4,0)/.3)).*exp(-max(t-4,0)/6);taus=[.15 .35 .55];err=zeros(3,1);poles=err;
for j=1:3,a=exp(-dt/taus(j));poles(j)=a;y=filter(1-a,[1 -a],x);z=(y-a*[0 y(1:end-1)])/(1-a);err(j)=max(abs(z-x));end
r=struct('noise_free_inverse_max_error_kV',max(err),'poles',poles,'all_stable',all(abs(poles)<1));
for j=1:3,f=openfig(fullfile('main','图',sprintf('fig%d.fig',j)),'invisible');assert(~isempty(findobj(f,'Type','axes')));close(f);end
fid=fopen('numeric_check.json','w');fprintf(fid,'%s',jsonencode(r));fclose(fid);disp(r);
end
