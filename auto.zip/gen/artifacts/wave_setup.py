from pathlib import Path
import json, shutil, urllib.request, concurrent.futures, datetime, hashlib
p=Path(json.loads(Path(r'D:\wkplace\auto\.paper-pipeline\scan-20261008-current.json').read_text(encoding='utf-8'))['projects'][1]['path'])
(p/'仿真').mkdir(exist_ok=True)
def w(n,s):(p/n).write_text(s,encoding='utf-8')
w('目标配置卡.md','''# 目标配置卡
EI会议研究稿，具体会议未定，不称投稿就绪；作者未提供，不编造。学科：电缆故障诊断、信号反演、机器学习。中英稿、原生可编辑公式、页码；3图2表，10条2021—2026年已核DOI。中文正文约4000汉字。项目原题保持，短题拟为一维卷积电缆行波波头反演。
遵循D:/wkplace/auto/test/script/README.md，FJH签署尚待提供。没有材料目录。
''')
w('实验设计.md','''# 冻结设计 R0
研究问题：电缆首行波经过低通测量链后，恢复传感器输入端波形及其50%上升沿时刻。不是故障点源信号重建，也不将单端定时误差称为完整定位误差。
依据无损传输线特征解u(t-z/v)，采用有限上升沿的双指数入射脉冲；电缆传播衰减和展宽在到达幅度、上升时间的独立范围中参数化。首波和延迟反射线性叠加，反射系数绝对值小于1；不声称是全频电缆电磁暂态等效。
采样dt=0.1微秒、192点；到达3—7微秒，波速180米/微秒对应540—1260米传播距离。入射幅值0.6—1.2 kV，上升时间0.15—0.6微秒，衰减时间4—9微秒；反射延迟3—6微秒、系数-0.35—0.35。传感器时间常数0.15—0.55微秒，零初值，离散精确一阶递推；等效带宽0.289—1.061MHz。SNR20/30/40dB按全记录无噪输出均方定义，白噪与AR(1)有色噪混合。有色噪系数0.6，噪声均方归一后叠加。
数据划分按独立事件：训练1800、验证300、测试450，每档噪声均衡。种子20261010；训练种子101/202/303，固定20轮、批64，全部模型同预算，不择种子。
基线：未经校正的测量信号；已知传感器时间常数的精确离散逆；已知同一时间常数的Tikhonov频域逆，lambda从1e-5到1按验证集波形MSE选；直接CNN；残差CNN。两个CNN均可用测量、正则逆和时间常数三通道输入，只差输出是直接波形还是正则逆残差，参数数目一致。卷积核9/9/9/1，24通道，扩张1/2/4，ReLU；非因果离线处理整段已采集记录，不宣称实时在线。
波形指标：逐事件RMSE/MAE(kV)；波头采用统一50%首个主峰上升沿线性插值，在全记录最大正峰之前找最近的半峰交叉。真值用同规则在干净传感器输入上计算；指标不是数学起始时刻。反射幅度受限，避免晚峰主导。定时绝对误差微秒，全部失败计入并报告。
主实验前Python数量级检查和独立小样本真实执行。贡献门禁：恢复波形/定时相对未校正观测有真实收益，强基线优势如实保留；不要求CNN全面胜出。图1典型波形，图2各方法误差，图3噪声分层定时；表1参数，表2总体指标。独立CSV复算。
''')
w('论文框架.md','''# 框架
1 引言：测量链畸变、行波波头学习现状、与已有小波系数反演的区别（650汉字）。
2 模型与任务：传播端脉冲、测量链、反射噪声、定时定义（850）。
3 方法：正则逆、条件卷积残差、公平训练、指标（1000）。
4 实验：独立事件划分、强基线、三种子、噪声分层、结果解释（1200）。
5 结论：回应波形和定时证据（300）。摘要数值待主实验，不提前写入。
''')
import numpy as np
q={'dt_us':.1,'bandwidth_MHz_range':[1/(2*np.pi*.55),1/(2*np.pi*.15)],'samples_per_fastest_rise':1.5,'distance_m_range':[540,1260],'max_discrete_pole':float(np.exp(-.1/.55)),'nyquist_MHz':5}
w('先导数量级.json',json.dumps(q,indent=2))
w('数据来源说明.md','''# 数据来源
公开候选FiN-2（https://zenodo.org/records/8328113）是电力线通信数据，不提供本研究所需同事件传感器输入/输出微秒级波头配对及测量链时间常数。现有波头反演论文报告其专用仿真，不直接等同开放配对训练集。本研究采用可复算参数化仿真，参数范围属于设计假设而非实测辨识；公开文献只支持问题背景和建模形式，不为自设数值背书。
已有研究10.32604/ee.2026.076354已采用一维卷积反演小波系数，本稿不声称首次提出CNN波头反演。差异限定为带已知测量时间常数的时域正则逆残差比较，且保留强解析基线。
''')
dois=['10.3390/en18143662','10.1109/TPWRD.2022.3230631','10.1109/TIM.2024.3383458','10.1016/j.epsr.2024.110598','10.1587/elex.19.20220113','10.32604/ee.2026.076354','10.1016/j.ymssp.2020.107398','10.1016/j.egyr.2023.04.130','10.1109/TII.2023.3308340','10.1049/stg2.12190']
def fetch(d):
 try:return {'doi':d,'checked_at':datetime.datetime.now().isoformat(),'metadata':json.loads(urllib.request.urlopen('https://api.crossref.org/works/'+d,timeout=45).read())['message']}
 except Exception as e:return {'doi':d,'error':str(e)}
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=5).map(fetch,dois));w('文献元数据.json',json.dumps(r,ensure_ascii=False,indent=2))
for z in r:print(z['doi'],z.get('metadata',{}).get('title'),z.get('metadata',{}).get('published'),z.get('error'))
shutil.copy2(Path(__file__).with_name('wave_experiment.m'),p/'仿真'/'wave_experiment.m')
print(p)
