from paper_helpers import project,references
import json,re
p=project(2);v=json.loads((p/'独立复算.json').read_text(encoding='utf-8'));m={int(r['method']):r for r in v['summary'] if r['budget_days']==7};gain=100*(1-m[4]['NRMSE']/m[3]['NRMSE']);gainy=100*(1-m[4]['NRMSE']/m[1]['NRMSE']);refs=references(p)
tzh='\n'.join(f"| {name} | {m[i]['NRMSE']:.4f} | {m[i]['NMAE']:.4f} |" for i,name in enumerate(['昨日复制','原始岭回归','随机表征','预测性对比','监督感知机'],1));ten='\n'.join(f"| {name} | {m[i]['NRMSE']:.4f} | {m[i]['NMAE']:.4f} |" for i,name in enumerate(['Yesterday','Raw ridge','Random features','Predictive contrastive','Supervised MLP'],1))
zh=r'''# 对比表征驱动的电表少样本负荷预测

**摘要：**针对新接入电表客户预测训练样本较少的问题，研究历史片段与后续日片段之间的自监督对比表征。源客户历史数据用于学习编码器，目标客户仅用少量日样本拟合冻结表征上的残差岭回归。采用公开小时级负荷基准，将预训练、验证与目标客户分组，并隔离验证和测试时段。20位目标客户、三个训练种子的结果表明，7日预算下所提方法的归一化均方根误差为0.1505，较同结构随机表征降低@G@%，较昨日复制降低@Y@%；14位客户获得改善。配对改善的95%区间为[0.0009,0.0035]。28日预算下原始岭回归更优，说明收益主要体现在本实验的短目标历史条件，不能解释为所有样本规模下的优势。

**关键词：**智能电表；少样本预测；自监督学习；预测性对比；负荷表征

## 1 引言

智能电表能够持续记录客户负荷，但新客户接入、历史记录迁移或有效数据积累不足时，单个客户可用于预测训练的连续样本仍然有限。短历史既限制模型参数估计，也容易使模型过度依赖最近几天的偶然变化。深度负荷预测综述强调了非平稳性、输入条件及评价设置之间的关系[1]。在此场景中，利用其他客户的已有记录学习可迁移模式，比直接扩大目标模型规模更值得检验。

少样本负荷预测已有基于元学习的研究，通过跨任务训练形成较易适应新客户的参数[2]。多任务住宅预测也已引入对比预训练，以提取共享的季节和趋势信息[3]。因此，对比学习用于负荷预测并不是新的概念。本文关注的具体问题是：当目标客户只有少量成对日样本时，源客户学到的表征是否比同结构随机映射更有帮助，以及这种帮助能否在简单统计基线存在时仍被辨识。

时序对比学习中，时间与上下文对比[4]、层次化表示学习[5]及通用时序表征[6]分别探索了不同的正负样本构造和训练目标。针对预测任务，时序依赖本身需要在预训练中得到体现[7]。相关综述也区分了生成、对比等自监督路线[8]。仅让同一历史片段的扰动视图接近，可能保留实例身份，却不一定保留后续负荷变化所需的信息；故本文直接建立历史与后续日片段的对应关系。

本文以真实公开电表衍生基准开展客户与时间双重隔离实验，使用冻结编码器和小规模线性输出层控制目标训练需求。研究贡献是检验预测性对比在7、14、28日目标预算下的实际收益，并以随机表征、原始岭回归和监督网络揭示收益来源。所有预测输出均使用历史尺度归一化；不把相对误差改称绝对功率精度，也不将少样本解释为减少人工电量标注费用。

## 2 数据与少样本任务

### 2.1 公开数据及尺度

实验来源为Artur Trindade于2015年提供的ElectricityLoadDiagrams20112014，原始来源为UCI，数据DOI为10.24432/C58C86，许可为CC BY 4.0。本次使用Guokun Lai等公开仓库提供的小时级321客户衍生版本，共26304个时间点。固定取前60列与前6000行，不依据测试效果选客户。原仓库与UCI对聚合量纲的说明不完全一致，因此本文只报告无量纲相对负荷；该来源年份如实保留，不将数据集列入近期方法文献以改写年份。

每24个连续记录定义一个日块，保留文件行序，不人为指定日期或客户身份。数据中没有缺失数值，真实零值予以保留，未进行插值或跨客户求和。原始测量的夏令时编码也不由本研究猜测修正。公开数据包含不同规模客户，不能把前60列自动称为60个住宅。归属、版本对象哈希、下载文件哈希及截取步骤随复现材料保存。

### 2.2 因果归一化与标签预算

对客户$c$在预测起点$t$之前的72小时负荷，计算历史均值，并用同一尺度处理历史和随后24小时目标：

$$ \mu_{c,t}=\frac{1}{72}\sum_{j=1}^{72}l_{c,t-j},\quad x_{c,t,j}=\frac{l_{c,t-j}}{\mu_{c,t}}-1. \tag{1} $$

其中，$l$表示源文件中的负荷数值，$\mu$为相同原始尺度下的历史均值；$x$及归一化目标均无量纲。各窗口均值为正，不使用未来样本估计尺度。输出误差因此表示相对近期平均负荷的偏差，而非某一客户额定容量或实际功率的百分比。均值随预测起点更新，但训练后的网络和回归参数不随测试日更新。

少样本预算$K$取7、14、28，表示每位目标客户参与输出层拟合的完整日样本数。20位目标客户共同拟合一个回归头，7日预算合计140个样本，不等同于单客户独立学习。构造首个样本还需要此前72小时上下文，因此7日训练并不是总共只访问7日记录。测试采用每日滚动24小时预测，起点之前的新观测可作为输入，起点之后的真实负荷不能作为输入或重新训练标签。

### 2.3 客户与时间隔离

客户1—30用于预训练，31—40用于验证，41—60用于目标评估，集合互不重叠。预训练日块4—148，验证支持集截止176日、验证日177—190；目标支持集截止218日，保留测试日219—246。三个预算使用各截止日之前最近的$K$个样本。源预训练最晚目标位于第3552小时，验证最晚目标位于第4560小时，测试从第5233小时开始，调参不访问后续测试期。

## 3 预测性对比表征

### 3.1 历史与后续片段匹配

历史编码器由72维输入、64维双曲正切隐层和16维线性输出组成。预训练专用的后续日编码器采用24—64—16结构。对源数据中成对的历史与随后日片段分别构造视图，经两个编码器得到表示：

$$ z_i=f_\theta(\mathcal A(x_i)),\quad v_i=g_\phi(\mathcal A(y_i)). \tag{2} $$

式中，$y_i$为按同一历史均值归一化的后续24小时片段，$\theta$和$\phi$为两个编码器参数，$\mathcal A$为增强操作。增强包含标准差0.03的加性抖动、标准差0.03的乘性尺度扰动和5%的点掩码，掩码值为归一化均值零。不使用时间置乱，以保留小时顺序。这些扰动用于学习，不被称为原始数据中的真实测量噪声。

以余弦相似度构造历史到后续日的批内匹配概率：

$$ s_{ij}=\frac{z_i^\mathsf{T}v_j}{\|z_i\|\|v_j\|},\quad P_{ij}=\frac{e^{s_{ij}/T}}{\sum_k e^{s_{ik}/T}}. \tag{3} $$

其中，$T=0.2$为无量纲温度，内积及范数沿16个特征计算，实现中范数加入微小正数防止除零。同一源事件的历史和后续日为正对，同批其他事件为负对。另以列归一化定义反向概率$Q$，得到对称损失

$$ \mathcal L=-\frac{1}{2B}\sum_{i=1}^{B}(\log P_{ii}+\log Q_{ii}). \tag{4} $$

式中，$B$为实际批量，通常取128，末批保留剩余样本。源数据的后续片段来自已发生的历史记录，构成自监督对应关系，不需要人工类别标签；但这并不意味着未使用源域后续观测。目标客户的测试后续负荷始终不可见。相似客户可能形成难以区分的负对，因此损失下降不能单独证明预测效果提高，必须通过下游对照检验。

### 3.2 冻结表征与残差输出

预训练采用三个初始化种子101、202、303，各30轮，学习率0.001。随后丢弃后续日编码器，冻结历史编码器。预测特征由常数项、昨日对应24小时、记录日索引的周周期正余弦和16维历史表征组成。周相位只表示七日周期，不冒充实际周几。输出层对昨日复制的残差进行岭拟合：

$$ \begin{aligned}W&=(F^\mathsf{T}F+n\lambda R)^{-1}F^\mathsf{T}(Y-B_0),\\\hat Y&=B_0+FW.\end{aligned} \tag{5} $$

其中，$F$为带常数项的43维特征矩阵，$Y$为训练目标，$B_0$为昨日复制，$n$为支持样本数；$R$为除常数项外对角为1的惩罚矩阵，$\lambda$为岭系数。各预算分别在验证客户上从七个对数候选值中选择$\lambda$，范围为$10^{-4}$至$10^2$，目标客户测试集不参与选择。求解采用线性方程而不是数值显式求逆。

历史编码器含5712个参数，预训练后续日分支含2640个参数；推理时后者不保留。岭输出头有1032个系数。随机表征基线使用与历史编码器完全相同的初始权重、输出维数和回归特征，因此对比能够检验预训练是否提供增益。它不是零参数统计模型，也不能把其效果归因于自监督学习。原始岭回归直接使用72小时历史及相同周相位，监督感知机则仅用目标支持样本训练74—64—16—24网络。

### 3.3 统计口径

对每位客户合并28个测试日、每日24小时的归一化误差，计算

$$ E_c=\sqrt{\frac{1}{DH}\sum_{d=1}^{D}\sum_{h=1}^{H}(\hat y_{c,d,h}-y_{c,d,h})^2}. \tag{6} $$

式中，$D=28$、$H=24$，$E_c$为客户归一化均方根误差（NRMSE）；另计算归一化平均绝对误差（NMAE）。先按客户计算，再对客户和种子等权平均，避免大规模客户支配结果。配对分析先平均三个种子，再以20位客户为单位重采样5000次。相邻日历史窗口重叠，不能把全部小时点当作独立重复试验。

## 4 实验与结果

### 4.1 设置与复现检查

表1列出最终实验配置。预训练共有4350对片段；每个预算的测试均为相同20位客户和28日，不将预算重复计为新客户。全部方法获得同一历史输入和周周期信息，未来分支仅在源域预训练中使用。数据读取、网络优化和输出层计算真实执行，逐点预测另由独立程序复算。近期线性基线研究提示简单模型不可省略[9]，而聚合程度会影响负荷可预测性[10]，因此本文不通过跨客户聚合降低问题难度。

表1 最终数据划分与训练设置

| 项目 | 设置 |
|---|---|
| 源/验证/目标客户 | 1—30 / 31—40 / 41—60 |
| 源日/验证日 | 4—148 / 177—190 |
| 目标支持截止/测试日 | 218 / 219—246 |
| 输入/预测长度 | 72 h / 24 h |
| 每客户预算 | 7、14、28个日样本 |
| 对比批量/轮数/种子 | 128 / 30 / 101、202、303 |
| 岭参数/温度 | 七档验证选择 / 0.2 |

图1展示预先固定的首位目标客户、首测试周及种子101。纵轴为预测起点历史均值归一化后的负荷，跨日分母可能变化。所提方法能够修正部分昨日复制误差，但不能精确恢复所有局部波动。该示例不用于选择最佳客户，后续指标保留全部目标客户。

![首周预测](仿真/R1/图/fig1.png)

图1 首位目标客户的首周逐日24小时预测

### 4.2 七日预算的主比较

表2中预测性对比的NRMSE为0.1505、NMAE为0.1113；随机表征分别为0.1527和0.1130。NRMSE相对随机表征降低@G@%，相对昨日复制降低@Y@%。平均客户配对改善为0.0022，95%自助区间为[0.0009,0.0035]；20位客户中14位改善，仍有6位未改善，不能将总体收益说成所有客户均受益。

表2 七日预算下的客户平均误差

| 方法 | NRMSE | NMAE |
|---|---|---|
@TABLE@

三个种子的对比NRMSE分别为0.1501、0.1509、0.1505，均低于各自随机表征的0.1515、0.1527、0.1541。原始岭回归为0.1539，说明在该短支持集上，预测性表征补充了昨日负荷之外的有用信息。监督感知机为0.1688，未优于昨日复制，提示仅增加可训练参数并不能弥补样本不足；但该结果只针对固定训练预算，不能代表所有监督网络的上限。

### 4.3 预算与预测步长

图2给出三种预算的客户均值及标准差。14日时对比NRMSE为0.1474，原始岭回归为0.1476，差距已经很小；28日时对比为0.1504，原始岭回归为0.1495，简单模型更好。训练历史变长也未保证误差单调下降，可能受到较早模式与当前负荷变化不一致的影响；本实验没有额外因果干预，不能把这一解释写成已证明机制。

![预算比较](仿真/R1/图/fig2.png)

图2 不同训练日预算的NRMSE，误差棒为跨客户标准差

图3按预测小时合并平方误差再开方，用于展示日内误差分布，与表2先计算客户RMSE再平均的口径不同。曲线比较不支持所有小时均为同一方法最优。对比方法的总体收益来自多个预测位置共同作用，而非人为删除高误差时段。三种子、五方法、三预算共604800行输出均保留，独立复算与主程序一致。

![逐小时误差](仿真/R1/图/fig3.png)

图3 七日预算的逐预测小时合并归一化RMSE

### 4.4 设计修订与应用条件

初始方案采用同一历史片段的双增强，七日预算未优于随机表征，因而没有据此成文。修改为历史—后续日匹配后，使用新的后续测试日重新检验，旧结果与代码保留。由于两轮测试时期不同，本文不把两轮误差之差当作损失函数的纯消融效果；最终证据来自同一新测试集上的随机表征对照。

当前实验没有天气、客户类别及异常事件标签，也没有验证逐个新客户独立适配。对比预训练增加源域计算成本，冻结阶段虽避免重训编码器，仍需源客户可共享的历史记录。结论适用于该公开基准固定客户子集及已给出的时段；迁移到其他区域或计量体系时，应重新检验数据尺度、隐私约束和分布变化。

## 5 结论

本文将历史与后续日的预测性对比用于电表少样本负荷表征，并通过冻结编码器上的残差岭回归利用有限目标样本。独立客户和时间隔离下，7日预算的NRMSE为0.1505，相对随机表征降低@G@%，配对区间支持有限但可复算的改善。更长预算下优势缩小，28日时原始岭回归更好。结果支持短目标历史条件下使用预测性表征，同时保留简单基线与客户异质性，后续需扩展到更多时间段及独立客户部署。

## 参考文献

@REFS@
'''
en=r'''# Predictive Contrastive Representations for Few-Shot Smart-Meter Load Forecasting

**Abstract:** Newly available smart-meter histories may provide only a few daily examples for forecasting. This study learns self-supervised correspondences between historical windows and subsequent daily segments from source customers, then fits a residual ridge head on frozen representations using limited target examples. A public hourly electricity benchmark is separated by customer group and time. Across 20 target customers and three training seeds, the seven-day setting achieves a normalized root-mean-square error of 0.1505, @G@% below an otherwise identical random-feature model and @Y@% below previous-day copying. Fourteen customers improve, and the 95% paired bootstrap interval is [0.0009, 0.0035]. Raw-feature ridge regression performs better with a 28-day budget. The evidence supports a modest benefit under short target histories, rather than universal superiority across training-set sizes.

**Keywords:** smart meter; few-shot forecasting; self-supervised learning; predictive contrasting; load representation

## 1 Introduction

Smart meters continuously record customer demand, yet newly connected customers, incomplete historical transfers, and short monitoring periods can leave few usable examples for forecasting. Short histories limit parameter estimation and encourage models to fit incidental recent behavior. A survey of deep load forecasting highlights the interaction between nonstationarity, input conditions, and evaluation design [1]. Reusing temporal information from established customers is therefore worth testing before simply increasing target-model size.

Few-shot load forecasting has been investigated through meta-learning, which learns parameters that can adapt to new customer tasks [2]. Multi-task residential prediction has also used contrastive pretraining to extract shared trends and seasonal representations [3]. Contrastive learning for load prediction is consequently not a new idea. The specific question here is whether source representations help more than an equally sized random mapping when target customers provide few paired daily examples, and whether that benefit remains visible against simple statistical baselines.

Temporal and contextual contrasting [4], hierarchical representation learning [5], and universal time-series representations [6] explore different positive pairs and training objectives. Forecast-oriented representations should reflect temporal dependence rather than merely inherit augmentation practices from other domains [7]. A broader survey distinguishes contrastive and generative self-supervision [8]. Matching two perturbed versions of one historical window can preserve instance identity without necessarily preserving information about subsequent load. This study instead explicitly matches history with the following daily segment.

The contribution is a customer- and time-isolated evaluation of predictive contrasting with seven-, fourteen-, and twenty-eight-day target budgets. A frozen encoder and small linear head limit target fitting. Random features, raw ridge regression, and a supervised network expose the role of pretraining. All reported outputs and errors are normalized by available historical load; no unverified absolute-power accuracy or manual-labeling saving is claimed.

## 2 Data and Few-Shot Task

### 2.1 Public data and scale

The source is ElectricityLoadDiagrams20112014, donated by Artur Trindade to UCI in 2015, DOI 10.24432/C58C86, under CC BY 4.0. The actual downloaded version is the 321-customer hourly benchmark published by Guokun Lai and collaborators, containing 26,304 observations. The first 60 columns and first 6,000 rows are selected by position, without performance-based filtering. The repository and original UCI documentation describe aggregation units differently; therefore, only dimensionless relative load is analyzed. The dataset's genuine 2015 provenance is stated here rather than being assigned a recent publication year.

Every 24 consecutive rows form a day block. File order is retained without inventing calendar dates or customer identities. There are no missing numerical values in the selected subset; zeros and the source's daylight-saving encoding are retained. No interpolation or aggregation across customers is performed. The subset must not be described automatically as 60 residential households. Attribution, Git-object identity, file hashes, and extraction steps accompany the reproduction materials.

### 2.2 Causal normalization and budget

For customer $c$ at forecast origin $t$, the preceding 72-hour mean normalizes both history and the following 24-hour target:

$$ \mu_{c,t}=\frac{1}{72}\sum_{j=1}^{72}l_{c,t-j},\quad x_{c,t,j}=\frac{l_{c,t-j}}{\mu_{c,t}}-1. \tag{1} $$

Here, $l$ and $\mu$ retain the source numerical scale, while $x$ and the normalized target are dimensionless. Every denominator is positive and uses only past observations. Errors describe deviations relative to recent average load, not a percentage of rated capacity or a verified kW quantity. The historical mean updates at each origin; learned encoder and head parameters remain fixed during testing.

Budget $K$ is 7, 14, or 28 complete daily training pairs per target customer. The 20 target customers jointly fit one head, so the seven-day setting provides 140 examples; it is not separate learning from seven examples for each isolated customer. An additional 72-hour context is required before the first support example. Daily rolling prediction permits observations available before the current origin as input, but never the subsequent target or test-period parameter updates.

### 2.3 Customer and temporal separation

Customers 1–30 provide pretraining data, 31–40 provide validation data, and 41–60 are evaluated. Source day blocks are 4–148. Validation support ends on day 176 and validation targets cover days 177–190. Target support ends on day 218; held-out testing covers days 219–246. Each budget takes the most recent $K$ support examples before its cutoff. The last source target is hour 3,552, the last validation target is hour 4,560, and testing starts at hour 5,233. Thus, customer sets are disjoint and tuning precedes the new test period.

## 3 Predictive Contrastive Representation

### 3.1 Matching history and subsequent segments

The history encoder has a 72-dimensional input, a 64-unit hyperbolic-tangent hidden layer, and a 16-dimensional linear output. A pretraining-only subsequent-day encoder has dimensions 24–64–16. Paired historical and subsequent source segments are independently augmented and encoded:

$$ z_i=f_\theta(\mathcal A(x_i)),\quad v_i=g_\phi(\mathcal A(y_i)). \tag{2} $$

The subsequent segment $y_i$ uses the same historical mean as its context. Parameters are $\theta$ and $\phi$, and augmentation $\mathcal A$ combines additive jitter with standard deviation 0.03, multiplicative scaling with standard deviation 0.03, and a 5% point mask set to the normalized mean of zero. Time order is preserved. These artificial training perturbations are not described as measured sensor noise.

Cosine similarity defines a within-batch matching probability from history to the subsequent day:

$$ s_{ij}=\frac{z_i^\mathsf{T}v_j}{\|z_i\|\|v_j\|},\quad P_{ij}=\frac{e^{s_{ij}/T}}{\sum_k e^{s_{ik}/T}}. \tag{3} $$

Temperature $T=0.2$ is dimensionless. Norms use 16 features and a small positive numerical stabilizer. The two segments from one source event form a positive pair; other batch events form negatives. Column normalization gives reverse probabilities $Q$, yielding the symmetric objective

$$ \mathcal L=-\frac{1}{2B}\sum_{i=1}^{B}(\log P_{ii}+\log Q_{ii}). \tag{4} $$

Batch size $B$ is normally 128, with the final partial batch retained. Subsequent source observations are historical records supplying a self-supervised correspondence, rather than manually assigned class labels. This does not mean that pretraining avoids subsequent source observations. Target test futures remain inaccessible. Similar customers can create ambiguous negatives, so a decreasing contrastive loss alone is insufficient evidence of forecasting improvement.

### 3.2 Frozen features and residual head

Pretraining uses seeds 101, 202, and 303, 30 epochs per seed, and a learning rate of 0.001. The subsequent-day branch is then discarded and the history encoder frozen. Forecast features concatenate an intercept, the previous day's 24 values, sine/cosine of a seven-day row-index phase, and the 16-dimensional history representation. The phase is not labeled as an actual weekday. The head fits a residual around previous-day copying:

$$ \begin{aligned}W&=(F^\mathsf{T}F+n\lambda R)^{-1}F^\mathsf{T}(Y-B_0),\\\hat Y&=B_0+FW.\end{aligned} \tag{5} $$

Here, $F$ contains 43 features including the intercept, $Y$ contains targets, $B_0$ is the previous-day forecast, and $n$ is support-set size. Penalty matrix $R$ has a zero intercept entry and unit remaining diagonal entries. Each budget selects $\lambda$ from seven logarithmic candidates between $10^{-4}$ and $10^2$ using validation customers only. Computation solves a linear system instead of forming an explicit numerical inverse.

The history encoder has 5,712 learned parameters, the discarded subsequent-day branch has 2,640, and the ridge head contains 1,032 coefficients. The random-feature baseline retains the identical initial history encoder, representation size, and head inputs, isolating the effect of pretraining. Raw ridge regression uses all 72 historical values and the same periodic phase. A supervised 74–64–16–24 multilayer perceptron is trained only on target support examples for 30 epochs. All learned predictors fit residuals around the same previous-day reference.

### 3.3 Statistical unit

For each customer, normalized errors are pooled over 28 test days and 24 forecast hours:

$$ E_c=\sqrt{\frac{1}{DH}\sum_{d=1}^{D}\sum_{h=1}^{H}(\hat y_{c,d,h}-y_{c,d,h})^2}. \tag{6} $$

With $D=28$ and $H=24$, $E_c$ is customer normalized RMSE (NRMSE). Normalized MAE (NMAE) is also reported. Metrics are averaged equally across customers and seeds, preventing large customers from dominating. Paired differences first average seeds, then bootstrap the 20 customers 5,000 times. Overlapping historical windows make adjacent daily examples dependent, so individual hourly points are not treated as independent replications.

## 4 Experiments and Results

### 4.1 Settings and reproduction checks

Table 1 summarizes the final configuration. Pretraining contains 4,350 segment pairs. Every budget evaluates the same 20 customers and 28 days; repeated budgets do not create new customers. Available history and periodic information are consistent across methods, while the subsequent-day branch is restricted to source pretraining. Computation was actually executed and pointwise predictions independently recomputed. Evidence supporting simple forecasting baselines [9] motivates raw ridge regression. Because aggregation affects load predictability [10], customers are not combined to make forecasting easier.

Table 1 Final data partition and training configuration

| Item | Setting |
|---|---|
| Source / validation / target clients | 1–30 / 31–40 / 41–60 |
| Source / validation days | 4–148 / 177–190 |
| Target support cutoff / test days | 218 / 219–246 |
| History / horizon | 72 h / 24 h |
| Per-client budgets | 7, 14, 28 daily pairs |
| Batch / epochs / seeds | 128 / 30 / 101, 202, 303 |
| Ridge coefficient / temperature | seven validation candidates / 0.2 |

The predetermined first target customer, first test week, and seed 101 are shown in Figure 1. Load is divided by each origin's historical mean, so the denominator can change between days. Predictive features correct some previous-day errors but do not reproduce every local fluctuation. This example does not select a favorable customer; all aggregate metrics retain the complete target group.

![First week](仿真/R1/图/fig1.png)

Figure 1 Daily 24-hour forecasts for the first target customer's first test week

### 4.2 Main seven-day comparison

Table 2 reports predictive-contrastive NRMSE of 0.1505 and NMAE of 0.1113, compared with 0.1527 and 0.1130 for random features. NRMSE decreases by @G@% relative to random features and @Y@% relative to previous-day copying. The mean paired customer improvement is 0.0022, with a 95% bootstrap interval of [0.0009, 0.0035]. Fourteen of 20 customers improve; the remaining six do not, so the aggregate benefit is not universal.

Table 2 Customer-average errors with seven support days

| Method | NRMSE | NMAE |
|---|---|---|
@TABLE@

Contrastive NRMSE across the three seeds is 0.1501, 0.1509, and 0.1505, below the corresponding random-feature values of 0.1515, 0.1527, and 0.1541. Raw ridge achieves 0.1539, suggesting that the learned representation supplies useful information beyond the previous day under the short support budget. The supervised perceptron reaches 0.1688 and does not outperform copying. Additional trainable parameters therefore do not compensate for limited examples in this configuration; this is not an upper bound on all supervised-network performance.

### 4.3 Support budget and forecast horizon

Figure 2 shows customer means and standard deviations for all budgets. With 14 support days, contrastive NRMSE is 0.1474 and raw ridge is 0.1476, leaving a small difference. With 28 days, contrastive NRMSE is 0.1504 and raw ridge is better at 0.1495. More historical support does not guarantee monotonically lower error. Earlier behavior may be less representative of current load, but no causal intervention was conducted to establish that explanation.

![Budget comparison](仿真/R1/图/fig2.png)

Figure 2 NRMSE by training-day budget; error bars show customer standard deviation

Figure 3 pools squared errors within each forecast hour before taking the square root. This differs from Table 2, which averages customer-level RMSE. The curves do not imply a single best method at every hour. Aggregate improvement reflects several forecast positions, with no removal of difficult periods. All 604,800 rows covering three seeds, five methods, and three budgets are retained; independent recomputation agrees with the experimental summary.

![Hourly errors](仿真/R1/图/fig3.png)

Figure 3 Pooled normalized RMSE by forecast hour for the seven-day setting

### 4.4 Design revision and deployment conditions

An initial same-history augmentation design did not outperform random features in the seven-day setting and was not used to support the paper. After replacing it with history-to-subsequent-day matching, a new later test period was evaluated, while the earlier code and results were preserved. Because the periods differ, their error difference is not treated as a controlled ablation of the loss. The final evidence comes from the matched random-feature comparison on the same new test set.

Weather, customer classes, and event annotations are unavailable here. Separate adaptation of one isolated new customer is also untested because the head pools the target group. Source pretraining adds computation and requires shareable historical records, although the target stage avoids encoder retraining. Transfer to other regions or metering systems requires renewed checks of scale, privacy constraints, and distribution shift. The present findings concern the fixed public-benchmark subset and specified time blocks.

## 5 Conclusion

Predictive contrasting between historical and subsequent daily segments was evaluated for few-shot smart-meter load forecasting. A frozen history encoder and residual ridge head use limited target support. Under customer and temporal separation, seven-day NRMSE is 0.1505, @G@% below random features, with a positive paired improvement interval. The advantage narrows with more support, and raw ridge performs better at 28 days. The results support a modest short-history benefit while retaining strong simple baselines and customer heterogeneity. Broader time periods and isolated-customer deployment remain to be examined.

## References

@REFS@
'''
for lang,s,table in [('zh',zh,tzh),('en',en,ten)]:
 s=s.replace('@G@',f'{gain:.2f}').replace('@Y@',f'{gainy:.2f}').replace('@TABLE@',table).replace('@REFS@',refs);(p/f'论文_{lang}.md').write_text(s,encoding='utf-8');body=s.split('## 1 ',1)[1].split('## 参考文献' if lang=='zh' else '## References')[0];body='\n'.join(x for x in body.splitlines() if not x.startswith(('|','![')) and not re.match(r'^(?:图|表)\d+\s|^(?:Figure|Table) \d+ ',x));print(lang,len(re.findall('[\u4e00-\u9fff]',body)),len(re.findall(r'\b\w+\b',body)))
print('gains',gain,gainy)
