from paper_helpers import project,references
import json,re
p=project(1);v=json.loads((p/'独立复算.json').read_text(encoding='utf-8'));m=v['metrics'];refs=references(p)
tablezh='\n'.join(f"| {name} | {m[str(i)]['rmse']:.4f} | {m[str(i)]['mae']:.4f} | {m[str(i)]['timing']:.4f} |" for i,name in enumerate(['观测信号','精确逆','正则逆','直接CNN','残差CNN'],1))
tableen='\n'.join(f"| {name} | {m[str(i)]['rmse']:.4f} | {m[str(i)]['mae']:.4f} | {m[str(i)]['timing']:.4f} |" for i,name in enumerate(['Observed','Exact inverse','Tikhonov','Direct CNN','Residual CNN'],1))
gain=100*(1-m['5']['rmse']/m['3']['rmse']);lam=json.loads((p/'仿真/main/summary.json').read_text())['lambda']
zh=r'''# 一维卷积电缆故障行波波头反演模型

**摘要：**针对电缆故障行波经有限带宽测量链后波形平滑、波头定时偏移的问题，建立含延迟反射及混合噪声的参数化模型，比较直接卷积反演与正则逆残差校正。模型以观测电压、正则逆结果及已知测量时间常数为输入，恢复传感器输入端波形。450个独立测试事件、三个训练种子的结果表明，残差模型的波形均方根误差为0.0105 kV，较正则逆降低@GAIN@%；半峰波头定时平均绝对误差由0.0289 μs降至0.0124 μs。直接卷积模型分别达到0.0096 kV和0.0111 μs，表现略优。结果说明卷积学习可改善给定测量模型下的波头恢复，同时表明残差结构并非必要优势来源。

**关键词：**电缆故障；行波波头；一维卷积；信号反演；正则化

## 1 引言

电缆故障行波包含突变发生及传播的信息，波头提取质量直接影响后续测距。有限带宽的测量链会衰减快速变化分量，使故障暂态的上升沿变缓；噪声又会干扰峰值和阈值交叉位置。因此，恢复波形与提取时刻是相关但不同的任务，仅报告分类准确率难以说明波头是否得到改善。已有综述总结了人工智能在电缆故障检测与定位中的应用，也指出数据条件与泛化验证的重要性[1]。

围绕行波识别，Lan等研究了护层电流模态波头的卷积识别[2]，混合线路研究采用改进变分模态分解提取故障信息[3]，波头频率方法则建立频率与故障距离的关系[4]。反射测量中，自编码重建用于区分故障反射和外部干扰[5]。这些工作说明学习与分解方法具有应用价值，但识别波头、恢复传感器输入和直接估计距离具有不同目标，不宜使用同一个性能数值替代全部环节的验证。

He等已提出基于一维卷积的小波细节系数反演，并以波头提取服务于双端定位[6]。本文不将卷积反演本身视为首次提出，而是研究已知测量时间常数时，时域直接学习和正则逆残差学习的差异。一维卷积适合从时间序列中提取局部模式[7]；在行波与干扰识别中也已有卷积融合方法[8]。针对本任务，保留精确逆和正则逆作为强解析对照，能够区分测量链补偿、噪声抑制和学习先验各自的作用。

本文建立独立事件划分的波形恢复实验，以同一半峰定义评价全部方法，同时报告整体误差和噪声分层结果。主要工作是给出可复算的测量链反演比较，检验残差校正是否优于直接学习，并保留不支持结构优势的结果。实验采用参数化仿真，目标为传感器输入端的到达波形，不把恢复结果等同于故障点原始激励或完整定位精度。

## 2 波形模型与反演任务

### 2.1 到达波形与测量链

无损传输线的单向特征解可写为随传播时延平移的波形。为覆盖不同上升速度与幅度，采用因果双指数脉冲表示到达传感器位置的入射电压，再叠加一个延迟反射分量：

$$ g(s)=(1-e^{-s/t_r})e^{-s/t_d}\mathbf{1}_{s\geq0},\quad x(t)=A[g(t-t_0)+\rho g(t-t_0-\Delta)] \tag{1} $$

其中，$x$和$A$为电压及幅值，单位kV；$t_0$为传播到达时刻，$t_r$与$t_d$为上升和衰减时间，$\Delta$为反射延迟，单位均为μs；$\rho$为无量纲反射系数，绝对值小于1。电缆损耗及展宽通过到达幅值和上升时间区间表示，这是一种低阶信号模型，不是全频分布参数电缆模型。各事件分别抽取参数，覆盖正、负反射而非仅生成单一理想阶跃。

测量链采用零初值一阶低通。对于采样间隔内保持的输入，其精确离散形式为

$$ y_n=a y_{n-1}+(1-a)x_n,\quad a=e^{-h/\tau},\quad z_n=y_n+\eta_n. \tag{2} $$

式中，$h$为采样间隔，$\tau$为已知测量时间常数，单位μs；$y_n$为无噪输出，$z_n$为观测电压，$\eta_n$为噪声。正时间常数保证极点位于单位圆内。噪声由白噪声和系数为0.6的自回归噪声混合，再按指定信噪比归一化。信噪比根据整个记录的无噪输出均方定义，各事件噪声独立。模型不包含饱和、量化和参数标定误差，后续结论均在该测量假设下解释。

### 2.2 波头与数据边界

反演目标为$x_n$而非噪声中的首个非零点。对每个重建波形，先确定最大正峰，在其之前寻找最近的半峰交叉，并在线性插值后得到时刻。真值波形使用相同规则。该操作避免把数学起始时刻与实验可检测波头混用；插值后的亚采样误差并不表示采样硬件分辨率提高。差分窗口算子[9]和时频波形匹配[10]代表其他提取路径，本文固定提取器以集中检验前端反演。

所有划分在生成独立事件时确定。同一事件的192点不会拆入不同集合，三个训练种子也不产生新的测试事件。公开电力线通信数据以节点测量和通信频谱为主，缺少本任务需要的同事件测量链输入输出配对及标定参数，故采用可复现仿真，未将公开数据或既有论文结果作为本实验样本。

## 3 条件卷积反演

### 3.1 解析逆与正则基准

由式(2)可以直接求得离散逆，但差分项会放大高频噪声。为获得稳定基准，在频域求解带二范数惩罚的最小二乘问题，得到

$$ \hat X_\lambda(\omega)=\frac{H^*(\omega)Z(\omega)}{|H(\omega)|^2+\lambda},\quad H(\omega)=\frac{1-a}{1-ae^{-j\omega}}. \tag{3} $$

其中，$Z$为观测的离散频谱，$H$为无量纲传递函数，星号表示复共轭，$\omega$为数字角频率，$\lambda$为无量纲正则系数。记录补零到384点后计算，截取原长度作为正则逆结果$b$。从预先固定的16个对数间隔候选值中，仅按验证集波形均方误差选取$\lambda$，不用测试集寻找最优参数。

### 3.2 直接学习与残差学习

网络输入为观测、正则逆和时间常数三个通道，其中时间常数沿记录重复。两种形式采用相同的卷积骨架：前三层卷积核宽度均为9，通道数24，扩张系数依次为1、2、4，接线性整流单元；末层核宽度为1，输出单通道。相同填充保持长度，局部感受野为57点，即5.7 μs，可同时覆盖快速上升沿和部分反射变化。

$$ \hat x^{D}=f_\theta([z,b,\tau]),\quad \hat x^{R}=b+c f_\theta([z,b,\tau]),\quad c=0.1\ {\rm kV}. \tag{4} $$

其中，$D$和$R$分别表示直接及残差形式，$\theta$为可学习参数，$c$是残差训练的幅值尺度。直接模型的数值输出按kV解释，残差网络输出为无量纲校正量。两者分别对干净波形和经$c$缩放的残差目标最小化均方损失。残差形式把解析恢复结果作为输出起点，但不能仅凭结构推断其一定更好。

训练使用相同的样本、随机种子、优化器和迭代预算，学习率0.001，批量64，固定20轮。网络参数量相同，但目标尺度不同，因此消融比较评价的是两种完整训练形式，不能把结果全部归因于加法连接。网络利用整段记录和两侧邻域，属于离线恢复，未验证在线因果处理或现场实时延迟。

### 3.3 指标与不确定性

先对每个事件计算波形均方根误差，再对事件和训练种子等权平均：

$$ E_i=\sqrt{\frac{1}{N}\sum_{n=1}^{N}(\hat x_{i,n}-x_{i,n})^2},\quad T_i=|\hat t_i-t_i|. \tag{5} $$

其中，$N=192$为记录长度，$E_i$单位kV，$T_i$单位μs。另报波形平均绝对误差。基线在三个种子中复用，不当作三倍独立样本。配对分析先对种子平均，再以事件为单位重采样5000次计算95%区间，避免把记录中的采样点视为独立试验。

## 4 实验与结果

### 4.1 设置与数值核验

数据种子为20261010，训练种子101、202、303。训练、验证和测试分别为1800、300、450个事件，每组均衡包含20、30、40 dB噪声。表1列出冻结参数；这些范围是设计假设，不冒充某型号电缆或传感器的实测辨识值。0.1 μs采样对应5 MHz奈奎斯特频率，高于0.289—1.061 MHz测量链带宽。无噪声解析逆恢复误差达到浮点舍入量级，验证离散正向与逆向实现一致。

表1 参数与实验划分

| 项目 | 取值 | 单位/说明 |
|---|---|---|
| 采样/记录 | 0.1 / 192 | μs / 点 |
| 到达时刻/幅值 | 3—7 / 0.6—1.2 | μs / kV |
| 上升/衰减时间 | 0.15—0.6 / 4—9 | μs |
| 反射延迟/系数 | 3—6 / −0.35—0.35 | μs / 无量纲 |
| 测量时间常数 | 0.15—0.55 | μs |
| 训练/验证/测试 | 1800 / 300 / 450 | 独立事件 |
| 信噪比/训练种子数 | 20、30、40 / 3 | dB / 次 |

图1采用预先固定的首个测试事件和种子101。观测信号的上升沿受到平滑，解析正则逆减小迟滞但保留部分噪声；卷积输出同时利用邻域形态和测量参数恢复波形。示例仅用于解释信号变化，整体判断以全部事件为准。

![波形比较](仿真/main/图/fig1.png)

图1 首个测试事件的输入、观测及恢复波形

### 4.2 总体比较与结构检验

表2采用逐事件指标的种子平均。残差模型的RMSE为0.0105 kV，相比正则逆0.0415 kV降低@GAIN@%；定时误差由0.0289 μs降至0.0124 μs，说明波形改善同时作用于固定波头提取器。450个事件经种子平均后均有波形误差降低，平均配对改善0.0310 kV，95%自助区间为[0.0301,0.0320] kV。

表2 全部测试事件的平均误差

| 方法 | RMSE/kV | MAE/kV | 定时MAE/μs |
|---|---|---|---|
@TABLE@

直接模型取得0.0096 kV及0.0111 μs，均略优于残差形式。这与先导阶段的排序不同，表明短时训练结果不能替代充分预算下的比较。在当前低阶模型和样本规模下，直接网络已能同时学习测量补偿与降噪；固定正则逆的偏差并不一定需要通过残差形式更容易修正。本文因此保留直接学习这一更简单的输出形式，不宣称残差连接具有普遍优势。

![波形误差](仿真/main/图/fig2.png)

图2 波形RMSE均值及跨事件标准差，先对三个种子平均

图2中精确逆误差较大，原因是它在恢复带宽的同时放大观测噪声；正则项抑制这一效应，但引入幅度及平滑偏差。卷积模型利用训练分布中的脉冲形态得到更低误差。三个种子的残差RMSE分别为0.0104、0.0106、0.0104 kV，直接模型分别为0.0100、0.0099、0.0089 kV，排序没有依赖单个最优种子的挑选。

### 4.3 噪声影响与讨论

图3使用对数纵轴展示三个噪声档位。20 dB下精确逆定时误差升至1.1099 μs，正则逆为0.0522 μs，直接和残差模型分别为0.0212、0.0228 μs。噪声降低后，精确逆迅速改善，40 dB时达到0.0081 μs，甚至优于固定正则逆的0.0145 μs。这说明全局正则参数在低噪声下仍可能产生过度平滑，不能将其总体均值误解为各工况均最优。

![噪声分层](仿真/main/图/fig3.png)

图3 不同信噪比的半峰波头定时误差，纵轴为对数尺度

全部1296000条逐点预测记录经独立程序复算，与主程序汇总一致。较小的插值误差来自平滑信号和固定定义，并不证明对任意故障、未知带宽或脉冲干扰均可靠。尚未开展传感器标定偏差、分布外波形及实体电缆实验。对于这些变化，应重新评估测量模型和训练分布；当前结果支持已知低通测量链下的恢复收益。

## 5 结论

本文建立一维卷积电缆故障行波波头反演比较模型，将测量链补偿和波形先验结合，并通过独立事件划分检验恢复与定时两个目标。残差模型相对正则逆的波形RMSE降低@GAIN@%，半峰定时MAE降至0.0124 μs，三个训练种子的结果一致支持恢复收益。直接模型达到更低的0.0096 kV和0.0111 μs，说明残差形式不是本任务的必需优势结构。研究为已知带宽下的卷积波头恢复提供可复算证据，后续应验证测量失配和实体电缆工况。

## 参考文献

@REFS@
'''.replace('@GAIN@',f'{gain:.2f}').replace('@TABLE@',tablezh).replace('@REFS@',refs)
en=r'''# One-Dimensional Convolutional Inversion of Cable-Fault Traveling-Wave Fronts

**Abstract:** Limited measurement bandwidth smooths cable-fault transients and shifts detected wavefronts. A parametric model with delayed reflections and mixed noise is used to compare direct convolutional inversion with residual correction of a regularized inverse. Both networks receive the measured voltage, a regularized reconstruction, and the known measurement time constant. Across 450 independent test events and three training seeds, the residual model achieves a waveform root-mean-square error of 0.0105 kV, @GAIN@% below the regularized inverse, while half-peak timing mean absolute error decreases from 0.0289 to 0.0124 μs. Direct convolutional prediction performs slightly better, reaching 0.0096 kV and 0.0111 μs. The results support learned waveform recovery under the specified measurement model, but do not establish an inherent advantage of residual output correction.

**Keywords:** cable fault; traveling-wave front; one-dimensional convolution; signal inversion; regularization

## 1 Introduction

Traveling-wave transients carry information about fault initiation and propagation. Measurement bandwidth attenuates rapidly varying components, broadens the rising edge, and changes a detected arrival time. Noise additionally perturbs the peak and threshold crossing. Waveform reconstruction and timing are therefore related objectives, but classification accuracy alone does not demonstrate improved wavefront recovery. A recent review describes artificial intelligence applications to cable fault detection and localization and emphasizes data availability and generalization challenges [1].

Lan et al. investigated convolutional recognition of modal fronts in cable sheath currents [2]. Modified variational mode decomposition has been applied to overhead–cable hybrid lines [3], while wavefront-frequency methods relate transient frequency information to fault distance [4]. Autoencoder reflectometry has also been used to discriminate cable reflections from interference [5]. These studies address different stages of a fault-analysis chain. Detecting a front, reconstructing a sensor input, and estimating a complete fault location must consequently be evaluated separately.

One-dimensional convolutional inversion of wavelet detail coefficients has already been reported for traveling-wave localization [6]. This work does not claim that neural wavefront inversion is new. Instead, it compares two time-domain output formulations when the measurement time constant is known. Compact convolutional networks provide local temporal feature extraction [7], and convolutional fusion has also been studied for distinguishing traveling waves from clutter [8]. Strong analytical inverses are retained here to expose the separate effects of bandwidth compensation, noise amplification, and learned waveform priors.

The study uses independent simulated events, a common half-peak detector, multiple training seeds, and noise-stratified evaluation. Its contribution is a reproducible comparison of direct prediction and regularized-inverse residual correction, including evidence against a universal benefit of the residual formulation. The target is the waveform arriving at the sensor input, rather than the original fault excitation or a complete two-terminal location estimate.

## 2 Waveform Model and Task

### 2.1 Incident waveform and measurement chain

A one-way solution of a lossless transmission line propagates a waveform by a time shift. A causal finite-rise pulse is used to parameterize the voltage arriving at the measurement position, with one delayed reflection:

$$ g(s)=(1-e^{-s/t_r})e^{-s/t_d}\mathbf{1}_{s\geq0},\quad x(t)=A[g(t-t_0)+\rho g(t-t_0-\Delta)]. \tag{1} $$

Here, voltage $x$ and amplitude $A$ are in kV; arrival time $t_0$, rise time $t_r$, decay time $t_d$, and reflection delay $\Delta$ are in μs; the reflection coefficient $\rho$ is dimensionless and has magnitude below one. Arrival amplitude and rise-time ranges parameterize attenuation and broadening. This is a reduced signal model, not a full frequency-dependent cable electromagnetic model. Independently drawn parameters produce positive and negative reflections instead of repeated copies of a single ideal step.

A zero-initial-state first-order low-pass measurement chain is represented by its exact sampled recursion for a held input:

$$ y_n=a y_{n-1}+(1-a)x_n,\quad a=e^{-h/\tau},\quad z_n=y_n+\eta_n. \tag{2} $$

The sampling interval $h$ and known measurement time constant $\tau$ are in μs. The noise-free output $y_n$, observed voltage $z_n$, and additive noise $\eta_n$ are in kV. A positive time constant places the discrete pole inside the unit circle. White noise is mixed with first-order autoregressive noise having coefficient 0.6, then normalized to the specified signal-to-noise ratio (SNR). SNR uses the mean-square noise-free measurement over the complete record. Events have independent noise realizations. Saturation, quantization, and calibration errors are outside the modeled measurement chain.

### 2.2 Wavefront definition and data separation

The target is the clean sensor input, rather than the first nonzero sample in a noisy record. For each waveform, the maximum positive peak is identified and the latest half-peak crossing before that peak is located. Linear interpolation provides the crossing time. The same detector is applied to the clean target and every reconstruction. Thus, timing error concerns an operational half-peak definition, not the mathematical onset of a causal signal. Subsample interpolation does not imply improved hardware sampling resolution. Difference-window operators [9] and time–frequency waveform matching [10] are alternative processing routes; the detector is fixed here to isolate the effect of waveform inversion.

Training, validation, and testing are separated by independent events before any temporal samples are used. No part of a 192-point event appears in another split. Repeated training seeds do not create additional independent test events. Public powerline-communication measurements provide node observations and communication spectra, but not the required paired microsecond sensor-input/output records with measurement calibration. Reproducible simulation is therefore used, with no existing paper results or public measurements relabeled as training data.

## 3 Conditional Convolutional Inversion

### 3.1 Analytical and regularized inverses

Equation (2) gives an exact discrete inverse, but its difference operation amplifies high-frequency measurement noise. A stable reference is obtained by minimizing a frequency-domain least-squares objective with a quadratic penalty:

$$ \hat X_\lambda(\omega)=\frac{H^*(\omega)Z(\omega)}{|H(\omega)|^2+\lambda},\quad H(\omega)=\frac{1-a}{1-ae^{-j\omega}}. \tag{3} $$

Here, $Z$ is the observed discrete spectrum, $H$ is the dimensionless transfer function, the asterisk denotes complex conjugation, $\omega$ is digital angular frequency, and $\lambda$ is dimensionless. Records are zero-padded to 384 points and reconstructed to their original length, yielding reference waveform $b$. The regularization strength is selected from 16 fixed logarithmic candidates using validation waveform mean-square error only. Test events are not used to tune this parameter.

### 3.2 Direct and residual formulations

Each input has three channels: observed voltage, regularized reconstruction, and the measurement time constant repeated along the record. Both formulations use three convolutional layers with kernel width 9, 24 channels, dilation factors 1, 2, and 4, and rectified linear activations. A final width-one convolution produces one output channel. Same padding preserves record length. The 57-point receptive field spans 5.7 μs, covering the leading edge and part of the reflection dynamics.

$$ \hat x^{D}=f_\theta([z,b,\tau]),\quad \hat x^{R}=b+c f_\theta([z,b,\tau]),\quad c=0.1\ {\rm kV}. \tag{4} $$

Superscripts $D$ and $R$ denote direct and residual outputs; $\theta$ contains learned parameters. Direct output values are interpreted in kV, while the residual-network output is dimensionless and multiplied by scale $c$. The training targets are respectively the clean waveform and the residual divided by $c$, using mean-square loss. The analytical estimate supplies a useful starting waveform, but that design alone cannot establish better final performance.

Both networks use identical samples, seeds, architecture size, and optimization budgets: a learning rate of 0.001, batch size 64, and 20 fixed epochs. Because target scaling differs, the comparison evaluates complete training formulations rather than attributing every difference solely to an additive connection. Both models process a completed record with two-sided context. Causal online operation and field-device latency are not claimed.

### 3.3 Metrics and uncertainty

Waveform error is first computed per event, followed by equal averaging over events and seeds:

$$ E_i=\sqrt{\frac{1}{N}\sum_{n=1}^{N}(\hat x_{i,n}-x_{i,n})^2},\quad T_i=|\hat t_i-t_i|. \tag{5} $$

Record length is $N=192$; $E_i$ is in kV and $T_i$ is in μs. Waveform mean absolute error is also reported. Deterministic baselines reused across seeds are not counted as additional trials. Paired differences are averaged over seeds and bootstrapped 5,000 times by event, avoiding the false assumption that adjacent samples are independent experiments.

## 4 Experiments and Results

### 4.1 Settings and numerical checks

The data seed is 20261010 and training seeds are 101, 202, and 303. There are 1,800 training, 300 validation, and 450 test events, balanced across SNR levels of 20, 30, and 40 dB within each split. Table 1 lists design ranges, which are simulation assumptions rather than measured identification values for a specific cable or sensor. Sampling at 0.1 μs gives a 5 MHz Nyquist frequency, above the measurement bandwidth range of 0.289–1.061 MHz. In the noise-free numerical check, the discrete inverse recovers the input to floating-point precision, confirming consistency of the forward and inverse implementations.

Table 1 Simulation parameters and event split

| Item | Value | Unit or meaning |
|---|---|---|
| Sampling / record | 0.1 / 192 | μs / points |
| Arrival / amplitude | 3–7 / 0.6–1.2 | μs / kV |
| Rise / decay | 0.15–0.6 / 4–9 | μs |
| Reflection delay / coefficient | 3–6 / −0.35–0.35 | μs / dimensionless |
| Measurement time constant | 0.15–0.55 | μs |
| Training / validation / test | 1800 / 300 / 450 | independent events |
| SNR / training seeds | 20, 30, 40 / 3 | dB / runs |

The predetermined first test event and seed 101 are shown in Figure 1. Measurement smoothing changes the rising edge. Regularized inversion reduces this lag but retains some noise, while learned recovery uses local morphology and the known measurement parameter. This event illustrates signal behavior; all aggregate conclusions use the complete test set.

![Waveforms](仿真/main/图/fig1.png)

Figure 1 Clean input, observation, and reconstructions for the first test event

### 4.2 Overall comparison and output formulation

The metrics in Table 2 are event-level errors averaged over training seeds. Residual reconstruction achieves 0.0105 kV RMSE, @GAIN@% below the regularized inverse at 0.0415 kV. Timing MAE decreases from 0.0289 to 0.0124 μs, demonstrating that waveform recovery benefits the fixed detector. All 450 events show lower waveform error after seed averaging. The mean paired improvement is 0.0310 kV, with a 95% event-bootstrap interval of [0.0301, 0.0320] kV.

Table 2 Mean errors over all test events and seeds

| Method | RMSE/kV | MAE/kV | Timing MAE/μs |
|---|---|---|---|
@TABLE@

Direct prediction performs slightly better, with 0.0096 kV waveform RMSE and 0.0111 μs timing MAE. Its ordering differs from the short pilot experiment, showing why a two-epoch trial cannot replace a full-budget comparison. Under the present signal model and training-set size, a direct network can jointly learn compensation and denoising. Correcting a fixed regularized estimate is not necessarily easier than directly mapping the same information to the target. The results therefore retain direct prediction as the better output formulation and do not support a universal residual-connection advantage.

![Waveform errors](仿真/main/图/fig2.png)

Figure 2 Mean waveform RMSE with event standard deviation after seed averaging

The exact inverse has the largest overall waveform error because bandwidth restoration also amplifies noise. Regularization controls this amplification but introduces bias. Convolutional predictors exploit the training distribution's pulse morphology to reduce error further. Residual RMSE is 0.0104, 0.0106, and 0.0104 kV across the three seeds; direct RMSE is 0.0100, 0.0099, and 0.0089 kV. Thus, the comparison does not depend on selecting a favorable single run. Figure 2 shows event variability, not a confidence interval from treating all temporal samples as independent observations.

### 4.3 Noise stratification and interpretation

Figure 3 uses a logarithmic vertical axis to display the three SNR regimes. At 20 dB, exact-inverse timing error reaches 1.1099 μs, compared with 0.0522 μs for regularized inversion and 0.0212/0.0228 μs for direct/residual prediction. At 40 dB, the exact inverse improves to 0.0081 μs and outperforms the fixed regularized inverse at 0.0145 μs. A globally selected regularization strength can therefore oversmooth low-noise events; its aggregate advantage is not uniform across conditions.

![Noise stratification](仿真/main/图/fig3.png)

Figure 3 Half-peak timing MAE by SNR, with a logarithmic vertical scale

All 1,296,000 pointwise prediction rows were independently recomputed and agreed with the experimental summary. Small interpolation errors reflect smooth waveforms and a fixed operational detector, not proof of reliability for arbitrary faults, unknown bandwidth, or impulsive interference. Calibration mismatch, out-of-distribution pulses, and physical cable experiments remain untested. These changes require renewed evaluation of the measurement model and training distribution. The present evidence concerns recovery under a known low-pass measurement chain.

## 5 Conclusion

A one-dimensional convolutional comparison model was established for cable-fault wavefront inversion, combining analytical measurement compensation with learned waveform information. Independent-event testing demonstrates a @GAIN@% waveform RMSE reduction for residual correction relative to regularized inversion and a timing MAE of 0.0124 μs. Direct prediction performs better at 0.0096 kV and 0.0111 μs, showing that residual output correction is not a necessary advantage in this task. The study provides reproducible evidence for known-bandwidth wavefront recovery; measurement mismatch and physical cable conditions require further validation.

## References

@REFS@
'''.replace('@GAIN@',f'{gain:.2f}').replace('@TABLE@',tableen).replace('@REFS@',refs)
for lang,s in [('zh',zh),('en',en)]:
 (p/f'论文_{lang}.md').write_text(s,encoding='utf-8')
 print(lang,'hanzi',len(re.findall('[\u4e00-\u9fff]',s.split('## 1 ',1)[1].split('## 参考文献' if lang=='zh' else '## References')[0])),'words',len(s.split()))
print('lambda',lam,'gain',gain)
